#!/bin/sh

/usr/bin/intltoolize
automake
autoconf


