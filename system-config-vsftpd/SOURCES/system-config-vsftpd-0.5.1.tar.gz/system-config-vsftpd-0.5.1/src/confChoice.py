#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import GTK and PyGTK libraries
import gtk
import pygtk
pygtk.require('2.0')

# Import stock python libraries
import gettext
_ = gettext.gettext

class chooseConfig:

    def __callback(self, widget, data=None):
        #print "%s was toggled %s" % (data, ("OFF", "ON")[widget.get_active()])
        if widget.get_active():
            self.file = data

    def __close_application(self, widget, event, data=None):
        #if __name__ == "__main__":
        #    gtk.main_quit( )
        self.file = self.comboEntry.get_active_text( ) 
        self.window.hide( )
        return self.file

    def __init__( self, parent, confList ):

        self.file = confList[0]

        self.window = gtk.Dialog( _("Please choose ..."), parent, gtk.DIALOG_MODAL )
  
        self.window.connect( "delete_event", self.__close_application )
        self.window.set_border_width( 0 )
        self.window.set_resizable( False )
        self.window.set_modal( True )
        
        box2 = gtk.VBox( False, 10 )
        box2.set_border_width( 10 )
        self.window.vbox.pack_start( box2, True, True, 0 )
        box2.show( )

        comboModel = gtk.ListStore( str )
        self.comboEntry = gtk.ComboBoxEntry( comboModel )
        self.comboEntry.show( )
        comboText = gtk.CellRendererText( )
        self.comboEntry.pack_start( comboText, True )
        box2.pack_start( self.comboEntry, True, False, 0 )

        for path in __confList:
            comboModel.append( [ path ] )

        self.comboEntry.set_active( 0 )

        button = gtk.Button(_("OK"))
        button.connect_object("clicked", self.__close_application, self.window,
                              None)
        self.window.action_area.pack_start(button, True, True, 0)
        button.set_flags(gtk.CAN_DEFAULT)
        button.grab_default()
        button.show()

    def run( self ):

        result = self.window.run()
        self.window.destroy( )

        return self.file
