#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import GTK libraries
import gtk 
import gobject

class PrimitiveObjects:
    
    """
    Class rendering all primitive objects and abstract possibly redundant staff like show function..
    """

    def __exception(self, message, id):
        """
        Simulate throwing new exception with message and id
        Function prints message to stderr and exits with id code

        @param message: exception text
        @type  message: C{string}
        @param id: id
        @type  id: C{integer}
        """
        if id >= 50:
            raise Exception("\n"+_("User Exception:")+" "+message)
        else: 
            raise Exception("\n"+_("Sytem Exception:")+" "+message)

    def renderAlignment( self, box, top, bottom, left, right, packing=[False, False] ):
        """
        Render alignment - is using with other primitive-render functions 
        
        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param top: top paddig
        @type  top: C{integer}
        @param right: right padding
        @type  right: C{integer}
        @param bottom: bottom padding
        @type  bottom: C{integer}
        @param left: let padding
        @type  left: C{integer}
        @param packing: packing in box 
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.Alignment
        """

        alignment = gtk.Alignment( 0.5, 0.5, 1.0, 1.0 )
        alignment.set_padding( top, bottom, left, right )
        if box != None: box.pack_start( alignment, packing[0], packing[1], 0 )
        alignment.show( )
    
        return alignment
    
    def renderHBox( self, box=None, align=None, packing=[False, False] ):
        """
        Render horizontal box with alignment

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: array with alignment padding: top, bottom, left, right.
                      For more information see: L{renderAlignment<renderAlignment>}
        @type  align: [C{integer}, C{integer}, C{integer}, C{integer}];
        @param packing: packing in box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.HBox
        """

        hBox = gtk.HBox( False, 0 )
        
        if align != None:
            (top, bottom, left, right) = align
            alignment = self.renderAlignment( box, top, bottom, left, right )
            alignment.add( hBox )
        elif box != None: box.pack_start( hBox, packing[0], packing[1], 0 )

        hBox.show( )
        if box == None and align != None: return (alignment, hBox)
        else: return hBox
    
    def renderVBox( self, box=None, align=None, packing=[False, False] ):
        """
        Render vertical box with alignment

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: array with alignment padding: top, bottom, left, right.
                      For more information see: L{renderAlignment<renderAlignment>}
        @type  align: [C{integer}, C{integer}, C{integer}, C{integer}];
        @param packing: packing in box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @rtype:  gtk.VBox
        """
        
        vBox = gtk.VBox( False, 0 )
        
        if align != None:
            (top, bottom, left, right) = align
            alignment = self.renderAlignment( box, top, bottom, left, right )
            alignment.add( vBox )
        elif box != None: box.pack_start( vBox, packing[0], packing[1], 0 )
  
        vBox.show( )
        if box == None and align != None: return (alignment, vBox)
        else: return vBox
 
    def renderVPaned( self, box, box1, box2, align=None, packing=[False, False], packing_top=[False, False], packing_bottom=[False, False] ):
        """
        Render horizontal paned boxes with aligment
        
        @param box: box to be packed in 
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param box1: box in left side of the pane
        @type  box1: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param box2: box in right side of the pane
        @type  box2: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: array with alignment padding: top, bottom, left, right.
                      For more information see: L{renderAlignment<renderAlignment>}
        @type  align: [C{integer}, C{integer}, C{integer}, C{integer}];
        @param packing: packing in box 
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @param packing_left: packing left side: resize and shrink 
        @type  packing_left: couple of boolean values [C{boolean}, C{boolean}]
        @param packing_right: packing right side: resize and shrink 
        @type  packing_right: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.HPaned
        """

        vpane = gtk.VPaned()

        return self.__renderPaned( vpane, box, box1, box2, align, packing, packing_top, packing_bottom )

    def renderHPaned( self, box, box1, box2, align=None, packing=[False, False], packing_left=[False, False], packing_right=[True, True] ):
        """
        Render horizontal paned boxes with aligment
        
        @param box: box to be packed in 
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param box1: box in left side of the pane
        @type  box1: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param box2: box in right side of the pane
        @type  box2: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: array with alignment padding: top, bottom, left, right.
                      For more information see: L{renderAlignment<renderAlignment>}
        @type  align: [C{integer}, C{integer}, C{integer}, C{integer}];
        @param packing: packing in box 
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @param packing_left: packing left side: resize and shrink 
        @type  packing_left: couple of boolean values [C{boolean}, C{boolean}]
        @param packing_right: packing right side: resize and shrink 
        @type  packing_right: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.HPaned
        """

        hpane = gtk.HPaned( )

        return self.__renderPaned( hpane, box, box1, box2, align, packing, packing_left, packing_right )

    def __renderPaned( self, pane, box, box1, box2, align, packing, packing_left, packing_right ):
        """
        Render horizontal paned boxes with aligment
        
        @param box: box to be packed in 
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param box1: box in left side of the pane
        @type  box1: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param box2: box in right side of the pane
        @type  box2: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: array with alignment padding: top, bottom, left, right.
                      For more information see: L{renderAlignment<renderAlignment>}
        @type  align: [C{integer}, C{integer}, C{integer}, C{integer}];
        @param packing: packing in box 
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @param packing_left: packing left side: resize and shrink 
        @type  packing_left: couple of boolean values [C{boolean}, C{boolean}]
        @param packing_right: packing right side: resize and shrink 
        @type  packing_right: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.HPaned
        """

        if box1 == None or box2 == None:
            self.__exception(_("Bad calling renderHPaned(): missing gtk.Box object"), 50)

        if align != None:
            (top, bottom, left, right) = align
            alignment = self.renderAlignment( box, top, bottom, left, right, packing=[True, True] )
            alignment.add( pane )
        elif box != None: box.pack_start( pane, packing[0], packing[1], 0 )

        pane.pack1( box1, resize=packing_left[0], shrink=packing_left[1] )
        pane.pack2( box2, resize=packing_right[0], shrink=packing_right[1] )

        pane.show( )
        return pane

    def renderComboBox( self, box=None, align=None, callbacks={}, list=[], packing=[True, True]):
        """
        Render ComboBox with callback function on changed signal

        @param box: box to be packed to 
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: array with alignment padding: top, bottom, left, right.
                      For more information see: L{renderAlignment<renderAlignment>}
        @type  align: [C{integer}, C{integer}, C{integer}, C{integer}];
        @param callbacks: dictionary of signals and functions to call when comboBox
        @type  callbacks: C{dictionary}
        @param list: list of combo items
        @type  list: C{list}
        @param packing: packing in box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.ComboBox
        """

        combo = gtk.combo_box_new_text( )
        combo.show()
        for item in list:
            combo.append_text( item )
        combo.set_active( 0 )

        for key in callbacks.keys():
            combo.connect( key, callbacks[key], combo )
        if align != None:
            (top, bottom, left, right) = align
            alignment = self.renderAlignment( box, top, bottom, left, right, packing=[False, False] )
            alignment.add( combo )
        elif box != None: box.pack_start( combo, packing[0], packing[1], 0 )
        
        return combo

    def renderTreeView( self, box, model, callbacks={}, selection_type=gtk.SELECTION_MULTIPLE, enable_tree_lines=False, packing=[True, True], grid_lines=None ):
        """
        Render TreeView with callback function on toggle row

        @param box: box to be packed to [gtk.Box or None]
        @type box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param model: TreeView model
        @type  model: C{gtk.TreeModel}
        @param callbacks: dictionary of sigals and functions to call
        @type  callbacks: C{dictionary}
        @param selection_type: selection type
        @type  selection_type: C{gtk.SELECTION_*}
        @param enable_tree_lines: enabling treeView lines
        @type  enable_tree_lines: C{boolean}
        @param packing: packing in box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.TreeView
        """

        if model == None:
            self.__exception(_("Bad renderTreeView "), 50)
        treeView = gtk.TreeView( model )
        
        selection = treeView.get_selection( )
        selection.set_mode( selection_type )
 
        for key in callbacks.keys():
            selection.connect( key, callbacks[key], treeView ) 

        treeView.set_enable_tree_lines( enable_tree_lines )
        if enable_tree_lines: treeView.set_grid_lines( gtk.TREE_VIEW_GRID_LINES_HORIZONTAL )
        treeView.show( )

        if gtk.gtk_version[0] == 2 and gtk.gtk_version[1] > 10: 
            if grid_lines != None: treeView.set_grid_lines( grid_lines )

        if box != None: 
            if type( box ) in [ type( gtk.ScrolledWindow())  ]: 
                box.add_with_viewport( treeView )
            else: box.pack_start( treeView, packing[0], packing[1], 0 )
        
        return treeView

    def renderTreeViewColumnText( self, treeView, label, id, expand=False, sort=False, visible=True, markup=True, callbacks={} ):
        """
        Render label to TreeView as TreeViewColumn 

        @param treeView: TreeView to render column to
        @type  treeView: C{gtk.TreeView}
        @param label: text label
        @type  label: C{string}
        @param id: position in columns
        @type  id: C{inteager}
        @param expand: if column should expand if there is some free place
        @type  expand: C{boolean}
        @param sort: if column should be sortable
        @type  sort: C{boolean}
        @param visible: if column is visible by default
        @type  visible: C{boolean}
        @param markup: if using markup in label is enabled
        @type  markup: C{boolean}
        @param callbacks: dictionary of signals and functions
        @type  callbacks: C{dictionary}
        @return: If parameter C{treeView} is not C{None} it returns nothing

             >>> if treeView != None: treeView.append_column( column )
             else: return column

        @rtype: gtk.TreeViewColumn
        @note: For every signal is sending id of column  
        """
        
        cell = gtk.CellRendererText( )
        #cell.set_property( 'cell-background', 'white' )
        for key in callbacks.keys():
            cell.connect( key, callbacks[key], id)
        if markup: column = gtk.TreeViewColumn( label, cell, markup=id )
        else:      column = gtk.TreeViewColumn( label, cell, text=id )
        if sort: 
            column.set_sort_indicator( True )
            column.set_sort_column_id( id )
        column.set_expand( expand )
        column.set_visible( visible )
        
        if treeView != None: treeView.append_column( column )
        else: return column
        
    def renderTreeViewColumnToggle( self, treeView, label, id, callbacks={}, ):
        """
        Render toggle button to TreeView as TreeViewColumn 

        @param treeView: TreeView to render column to
        @type  treeView: C{gtk.TreeView}
        @param label: text label
        @type  label: C{string}
        @param id: position in columns
        @type  id: C{integer}
        @param callbacks: dictionary of signals and functions
        @type  callbacks: C{dictionary}
        @return: If parameter C{treeView} is not C{None} it returns nothing

             >>> if treeView != None: treeView.append_column( column )
             else: return column

        @rtype: gtk.TreeViewColumn
        @note: For every signal is sending id of column
        """
        
        cell = gtk.CellRendererToggle()
        cell.set_property('activatable', True)
        for key in callbacks.keys(): 
            cell.connect( key, callbacks[key], treeView.get_model(), id)
            
        column = gtk.TreeViewColumn( label, cell )
        column.add_attribute(cell, "active", id)
        if treeView != None: treeView.append_column( column )
        else: return column
            
    def renderTreeViewColumnPixbuf( self, treeView, label, id, max_width=32 ):
        """
        Render picture to TreeView as TreeViewColumn

        @param treeView: TreeView to render column to
        @type  treeView: C{gtk.TreeView}
        @param label: text label
        @type  label: C{string}
        @param id: position in columns
        @type  id: C{integer}
        @param max_width: value of maximal width of column
        @type  max_width: C{integer}
        @return: If parameter C{treeView} is not C{None} it returns nothing

             >>> if treeView != None: treeView.append_column( column )
             else: return column

        @rtype: gtk.TreeViewColumn
        """
        
        cell = gtk.CellRendererPixbuf( )
        #cell.set_property( 'cell-background', 'white' )
        column = gtk.TreeViewColumn( label, cell )
        column.set_max_width( max_width )
        column.set_attributes(cell, pixbuf=id)
        
        if treeView != None: treeView.append_column( column )
        else: return column

    def renderNoteBook( self, box=None, tab_position=gtk.POS_TOP, packing=[True,True] ):
        """
        Render base staff of notebook. After this, please call renderNBPage for every new page in NB

        @param box: box to be packed to [gtk.Box]
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param tab_position: position of tabs
        @type  tab_position: C{gtk.POS_TOP} or C{gtk.POS_BOTTOM} or ...
        @param packing: packing in box
        @type  packing: couple of booleans [C{boolean}, C{boolean}]
        @rtype: gtk.Notebook
        """

        noteBook = gtk.Notebook( )
        noteBook.set_tab_pos( tab_position )
        noteBook.show( )
 
        if box != None: box.pack_start( noteBook, packing[0], packing[1], 0 )

        return noteBook

    def renderNBPage( self, noteBook, pageLabel, align=None, with_close_button=False, markup=True ):
        """
        This function is called after renderNoteBook func for every new page.

        @param noteBook: where will be page added
        @type  noteBook: C{gtk.Notebook}
        @param pageLabel: text label of the page
        @type  pageLabel: C{string}
        @param with_close_button: if you want close button next to the page label 
        @type  with_close_button: C{boolean}
        @param markup: if using markup in label is enabled
        @type  markup: C{boolean}
        @return: gtk.VBox which is inside the new tab
        @rtype: gtk.VBox
        """

        if align != None: 
            alignment, box = self.renderVBox( align=align, packing=[True, True] )
        else: box = self.renderVBox( packing=[True, True] )

        label = gtk.Label( pageLabel )
        label.set_use_markup( markup )
        label.show( )

        if with_close_button:
            iconw = self.setIconStock( gtk.STOCK_CLOSE, gtk.ICON_SIZE_MENU )
            button = gtk.Button( )
            button.set_relief( gtk.RELIEF_NONE )
            button.set_image( iconw )
            button.show( )
            labelBox = self.renderHBox()
            labelBox.pack_start( label, True, True, 0 )
            labelBox.pack_start( button, False, False, 0 )
            noteBook.append_page( box, labelBox )
        else: 
            if align == None: noteBook.append_page( box, label )
            else: noteBook.append_page( alignment, label )

        return box

    def renderScrolledWindow( self, box=None, inbox=None, hpolicy=gtk.POLICY_AUTOMATIC, vpolicy=gtk.POLICY_AUTOMATIC, shadow=gtk.SHADOW_NONE, place=gtk.CORNER_TOP_LEFT ):
        """
        Render scrolled window with inbox within

        @param box: box to pack window in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or {None}
        @param inbox: inner box of window
        @type  inbox: C{gtk.VBox} or C{gtk.HBox} or {None}
        @param hpolicy: horisontal policy
        @type  hpolicy: C{gtk.POLICY*}
        @param vpolicy: vertical policy
        @type  vpolicy: C{gtk.POLICY}
        @param shadow: shadow of window
        @type  shadow: C{gtk.SHADOW*}
        @param place: placement of window
        @rtype: gtk.ScrolledWindow
        @todo [1.2]: make default values
        """

        scWindow = gtk.ScrolledWindow( )
        scWindow.set_policy( hpolicy, vpolicy )
        scWindow.set_shadow_type( shadow )
        scWindow.set_placement( place )
        # hack to silent Warnings
        if inbox != None:
            if type( inbox ) in [ type( gtk.VBox() ), type( gtk.Notebook() ), type( gtk.Fixed() ), type( gtk.Alignment() ) ]: 
                scWindow.add_with_viewport( inbox )
                inbox.get_parent().set_shadow_type( shadow )
            else: scWindow.add( inbox )
        
        scWindow.show( )
        
        if box != None: box.pack_start( scWindow, True, True, 0 )
        return scWindow

    def renderMenuBar( self, box=None, packing=[False, False] ):
        """ 
        Render top menu bar

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or {None}
        @param packing: packing in box
        @type  packing: list of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.MenuBar
        """

        menuBar = gtk.MenuBar( )
        menuBar.show( )
        if box != None: box.pack_start( menuBar, packing[0], packing[1], 0 )
        return menuBar

    def renderMenuItem( self, label, prefix=None, callbacks={}, gobject=None, Note=None, enabled=True ):
        """ 
        Render menu item with callback wich is called after recieved signal

        @param label: text label
        @type  label: C{string}
        @param prefix: prefix for keyboard interaction
        @type  prefix: C{string}
        @param callbacks: dictionary of signals and functions
        @type  callbacks: C{dictionary}
        @param gobject: graphical object - picture
        @type  gobject: C{gtk.Object}
        @param Note: some hints
        @type  Note: C{string}
        @param enabled: if button is enabled
        @type  enabled: C{boolean}
        @rtype: gtk.MenuItem
        """

        action = gtk.Action( label, prefix, Note, gobject)
        action.set_property('short-label', prefix)

        for key in callbacks.keys(): 
            action.connect( key, callbacks[key] )

        # create menu item
        item = action.create_menu_item()
        item.set_sensitive( enabled )
        item.show( )
        
        return item
    
    def renderCheckMenuItem( self, label ):
        """ 
        Render checkButton as menuItem 

        @param label: label of checkBox
        @type  label: C{string}
        @rtype: gtk.CheckMenuItem
        """

        # create menu item
        item = gtk.CheckMenuItem( label )
        item.show( )
        
        return item
    
    def renderRootMenuItem( self, label, prefix=None, menuBar=None, submenu=[] ):
        """ 
        Create root menu item with submenu

        @param label: text label
        @type  label: C{string}
        @param prefix: prefix for keyboard interaction
        @type  prefix: C{string}
        @param menuBar: to add this item into
        @type  menuBar: C{gtk.MenuBar}
        @param submenu: list of items which will make the submenu of this item
        @type  submenu: C{list}
        @rtype: gtk.MenuItem
        """

        item = self.renderMenuItem( label, prefix )
        
        if submenu != []:
            file_menu = gtk.Menu( )
            for subitem in submenu: file_menu.append( subitem )
            item.set_submenu( file_menu )
            
        if menuBar != None: menuBar.append( item )
        return item

    def renderToolBar( self, box=None, style=gtk.TOOLBAR_BOTH, tooltips=True, orientation=gtk.ORIENTATION_HORIZONTAL, border=0, packing=[False, False] ):
        """ 
        Render Tool Bar

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or {None}
        @param style: style of toolBar
        @type  style: C{gtk.TOOLBAR*}
        @param tooltips: if tooltips will be shown
        @type  tooltips: C{boolean}
        @param orientation: orientation of toolBar
        @type  orientation: {gtk.ORIENTATION*}
        @param border: border width
        @type  border: C{integer}
        @param packing: packing in box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.Toolbar
        """

        toolbar = gtk.Toolbar( )
        toolbar.set_style( style )
        toolbar.set_tooltips( tooltips )
        toolbar.set_orientation( orientation )
        toolbar.set_border_width( border )
        toolbar.show( )
        
        if box != None: box.pack_start( toolbar, packing[0], packing[1], 0 )
        return toolbar

    def setIconStock( self, icon, size=gtk.ICON_SIZE_SMALL_TOOLBAR ):
        """
        Render Image from STOCK icon

        @param icon: stock icon
        @type  icon: C{string} - path to icon file
        @param size: size of the image
        @type  size: C{gtk.ICON_SIZE_*}
        @rtype: gtk.Image
        """
        
        iconw = gtk.Image( )
        iconw.show()
        iconw.set_from_stock( icon, size )
        return iconw
    
    def renderEventBox( self, box=None, bg_color=None, packing=[False, False], events=None, callbacks={}, border=0 ):
        """
        Render container object gtk.EventBox

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param bg_color: color of eventBox background
        @type  bg_color: C{string}
        @param packing: packing in box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @param events: events to register
        @type  events: C{gtk events}
        @param callbacks: dictionary of signals and functions [dictionary]
        @type  callbacks: C{dictionary}
        @param border: border width
        @type  border: C{integer}
        @rtype: gtk.EventBox
        """
        
        eventBox = gtk.EventBox( )
        if events != None: eventBox.set_events ( events )
        eventBox.set_border_width( border )
        if bg_color != None: eventBox.modify_bg(gtk.STATE_NORMAL, eventBox.get_colormap().alloc_color(bg_color))
        for key in callbacks.keys(): 
            eventBox.connect( key, callbacks[key] )
        eventBox.show( )
        
        if box != None: box.pack_start( eventBox, packing[0], packing[1], 0 )
        return eventBox

    def renderOutputButtonArea( self, box ):
        """
        Render area under the output buttons, add some options here

        @param box: box to add to
        @type  box: C{gtk.Window*}
        @rtype: gtk.VBox
        @note: This is for renderVBox when box as first parameter have to be added by func add not pack_start
        """

        if box == None:
            self.__exception("Bad using renderOutputButtonArea(): missing box to add to gtk.VBox", 50)
        
        box1 = self.renderVBox( )
        box.add( box1 )
        return box1
        
    def appendMessage( self, model, message):
        """
        Append message to outputView

        @param model: TreeView model
        @type  model: C{gtk.TreeView}
        @param message: message to append
        @todo [1.2]: move to formatter
        """

        if model == None:
            self.__exception(_("Wrong call of appendMessage() function: missing gtk.TreeModel"), 50)
        if message == None:
            self.__exception(_("Wrong call of appendMessage() function: missing message string"), 50)
            
        model.get_model().append( message )

    def renderLabel( self, box=None, label="", align=None, markup=True, line_wrap_mode=gtk.WRAP_WORD, packing=[False, True], padding=[0,0] ):
        """
        Render simple label

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param label: text label
        @type  label: C{string}
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param markup: if using markup is enabled
        @type  markup: C{boolean}
        @param line_wrap_mode: if text should be wrapped
        @type  line_wrap_mode: C{gtk.WRAP*}
        @param packing: packing for box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @param padding: padding of label
        @type  padding: couple of integer values [C{integer}, C{integer}]
        @return: If align is not None, C{gtk.Alignment}, C{gtk.Label}, else C{gtk.Label}
        @rtype: gtk.Label
        """

        if label == None: 
            self.__exception(_("Wrong call of renderLabel(): expected string in label got None !"), 50)
            
    	label = gtk.Label( label )
    	label.set_use_markup( markup )
        label.set_line_wrap( line_wrap_mode != gtk.WRAP_NONE )
    	label.set_line_wrap_mode( line_wrap_mode )
        label.set_alignment( 0.0, 0.0 )
    	label.set_padding( padding[0], padding[1] )
    	label.show( )
        
    	if align != None:
            [top, bottom, left, right] = align
            alignment = self.renderAlignment( box, top, bottom, left, right, [False, False] )
            alignment.add( label )
            return alignment, label
        elif box != None:
            box.pack_start( label, packing[0], packing[1], 0 )
	
        return label

    def renderTextView( self, box=None, wrap_mode=gtk.WRAP_NONE, justify=gtk.JUSTIFY_LEFT, packing=[True, True], editable=False, accepts_tab=False ):
        """
        Render TextView 

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param wrap_mode: mdoe of wrapping text when reached the end of line
        @type  wrap_mode: C{gtk.WRAP*}
        @param justify: justify of text
        @type  justify: C{gtk.JUSTIFY*}
        @param packing: packing for box
        @type  packing: couple of boolean values [C{boolean}, C{boolean}]
        @param editable: set the text to be editable or not
        @type  editable: C{boolean}
        @param accepts_tab: if textView accepts <TAB>
        @type  accepts_tab: C{boolean}
        @rtype: gtk.TextView
        """
        

        buffer = gtk.TextBuffer( )
        textView = gtk.TextView( buffer )
        scWindow = self.renderScrolledWindow( None, textView )
        textView.set_wrap_mode( wrap_mode )
        textView.set_justification( justify )
        textView.set_editable( editable )
        textView.set_accepts_tab( accepts_tab )
        textView.show( )
        
        if box != None: 
            box.pack_start( scWindow, packing[0], packing[1], 0 )
            return textView
        
    def __renderSeparator( self, separator=None, box=None, align=None, packing=[True, True] ):
        """ 
        Render visible separator. Do not use this methode for rendering separator. 
        Use methods L{renderHSeparator<renderHSeparator>} or L{renderVSeparator<renderVSeparator>}

        @param separator: separator from renderHSpeparator or renderVSeparator
        @type  separator: C{gtk.VSeparator} or C{gtk.HSeparator}
        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.HSeparator or gtk.VSeparator
        """
        if separator == None:
            self.__exception(_("Wrong call of renderSeparator() function. You have to call renderHSeparator or renderVSeparator."), 51)
        if type(separator) != type(gtk.HSeparator()) and type(separator) != type(gtk.VSeparator()): 
            self.__exception(_("Wrong call of renderSeparator() function: \n  Wrong type of separator: ")+
                             `type(separator)`+
                             "\n  "+_("Expected:")+" "+`type(gtk.HSeparator())`+" "+_("or")+" "+`type(gtk.VSeparator())`+"\n", 51)
        
        if align != None:
            top, bottom, left, right = align
            alignment = self.renderAlignment( None, top, bottom, left, right )
            alignment.add( separator )
            if box != None: box.pack_start( alignment, packing[0], packing[1], 0 ) 
            return alignment, separator
        elif box != None: box.pack_start( separator, packing[0], packing[1], 0 ) 

        return separator

    def renderHSeparator( self, box=None, align=None, packing=[True,True] ):
        """
        Render horisontal separator

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.HSeparator
        """
        separator = gtk.HSeparator( )
        separator.show( )
        return self.__renderSeparator( separator, box, align, packing )
        
    def renderVSeparator( self, box=None, align=None, packing=[True,True] ):
        """
        Render vertical separator

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.HSeparator
        """
        separator = gtk.VSeparator( )
        separator.show( )
        return self.__renderSeparator( separator, box, align, packing )
     
    def renderProgressBar( self, box=None, align=None, packing=[True, True], label="" ):
        """
        Render ProgressBar

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @param label: text inside the ProgressBar
        @type  label: C{string}
        @rtype: gtk.ProgressBar
        """

        progressBar = gtk.ProgressBar()
        progressBar.set_text("")
        progressBar.queue_resize()
        progressBar.show()
        
        if align != None:
            top,  bottom, left, right = align
            alignment = self.renderAlignment( None, top, bottom, left, right )
            alignment.add( progressBar )
            if box != None: box.pack_start( alignment, packing[0], packing[1], 0 ) 
            return alignment, progressBar
        elif box != None: box.pack_start( progressBar, packing[0], packing[1], 0 )
        
        return progressBar
        
    def renderAnimation( self, box, path, align=None, packing=[False, False] ):
        """
        Render Image (Animation - GIF)

        @param  box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param path: path to image file
        @type  path: C{string}
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @rtype: gtk.Image
        """
        if path == None: 
            self.__exception(_("Wrong call of renderAnimation() function: missing image path"), 50)
        
        image = gtk.Image( )
        animation = gtk.gdk.PixbufAnimation( path )
        image.set_from_animation( animation )
        image.show( )
 
        if align != None:
            top, bottom, left, right = align
            alignment = self.renderAlignment( None, top, bottom, left, right, [False, False] )
            alignment.add( image )
            if box != None: box.pack_start( alignment, packing[0], packing[1], 0 )
        elif box != None: box.pack_start( image, packing[0], packing[1], 0 )

        return image

    def renderWindow( self, width, height, resizable=True, type=gtk.WINDOW_TOPLEVEL ):
        """
        Render Window

        @param width: width of window
        @type  width: C{integer}
        @param height: height of window
        @type  height: C{integer}
        @param resizable: if window will be resizable
        @type  resizable: C{boolean}
        @param type: type of window
        @type  type: C{gtk.WINDOW_*}
        @rtype: gtk.Window
        """
        
        window = gtk.Window( type )
        window.resize( width, height )
        window.set_default_size( width, height )
        window.set_resizable( resizable )
        
        return window

    def renderDialogWindow( self, parent, label="", width=0, height=0, resizable=True, border=0, modality=gtk.DIALOG_MODAL, modal=False, callbacks={} ):
        """
        Render Window

        @param width: width of window
        @type  width: C{integer}
        @param height: height of window
        @type  height: C{integer}
        @param resizable: if window will be resizable
        @type  resizable: C{boolean}
        @param border: border width
        @type  type: C{integer}
        @param modality: modality of window
        @type  modality: C{gtk.DIALOG_*}
        @param modal: modality of window
        @type  modal: C{boolean}
        @param callbacks: dictionary of signals and functions [dictionary]
        @type  callbacks: C{dictionary}
        @rtype: gtk.Dialog
        """
        
        window = gtk.Dialog( label, parent, modality )
        window.set_border_width( border )
        window.set_modal( True )
        if height != 0 and width != 0:
            window.resize( width, height )
            window.set_default_size( width, height )
        window.set_resizable( resizable )
        
        return window

    def renderButton( self, box, type=None, icon=None, size=gtk.ICON_SIZE_MENU, packing=[False, False], align=None, callbacks={}, label=None, relief=gtk.RELIEF_NORMAL ):
        """
        Render Button or ToggleButton or RadioButton 

        @param  box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param type: type of button 
        @type  type: C{toggle} | C{radio}
        @param icon: icon of button
        @type  icon: C{gtk.Image} or C{str} for stock
        @param size: size of the image
        @type  size: C{gtk.ICON_SIZE_*}
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param callbacks: dictionary of signals and functions [dictionary]
        @type  callbacks: C{dictionary}
        @rtype: gtk.Button or gtk.RadioButton or gtk.ToggleButton
        """
        if type == "toggle": 
            button = gtk.ToggleButton( )
        elif type == "check":
            button = gtk.CheckButton( )
        elif type == "radio":
            button = gtk.RadioButton( )
        elif type == "spin":
            button = gtk.SpinButton( )
        else: button = gtk.Button( )

        if icon != None:
            iconw = self.setIconStock( icon , size  )
            button.set_image( iconw )
        if type != "spin": button.set_relief( relief )
        button.show( )

        for key in callbacks.keys(): 
            button.connect( key, callbacks[key] )

        if label != None:
            try: button.set_label( label )
            except: pass

        if align != None:
            top, bottom, left, right = align
            alignment = self.renderAlignment( None, top, bottom, left, right, [False, False] )
            alignment.add( button )
            if box != None: box.pack_start( alignment, packing[0], packing[1], False )
        elif box != None: box.pack_start( button, packing[0], packing[1], False )

        return button
    
    def renderCheckButton( self, box, label, packing=[False, False], align=None, callbacks={}, active=False ):
        """
        Render CheckButton 

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param label: the button label
        @type  label: C{string}
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param callbacks: dictionary of signals and functions [dictionary]
        @type  callbacks: C{dictionary}
        @param active: If the button is checked
        @type  active: C{boolean}
        @rtype: gtk.Button or gtk.RadioButton or gtk.ToggleButton
        """

        button = self.renderButton( box, type="check", packing=packing, align=align, callbacks=callbacks, label=label )
        button.set_active( active )

        return button

    def renderRadioButton( self, box, label, group=None, packing=[False, False], align=None, callbacks={}, active=False ):
        """
        Render CheckButton 

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param label: the button label
        @type  label: C{string}
        @param group: Button group
        @type  group: C{gtk.RadioButton}
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param callbacks: dictionary of signals and functions [dictionary]
        @type  callbacks: C{dictionary}
        @param active: If the button is checked
        @type  active: C{boolean}
        @rtype: gtk.Button or gtk.RadioButton or gtk.ToggleButton
        @todo: box
        """

        button = self.renderButton( box, type="radio", packing=packing, align=align, callbacks=callbacks, label=label )
        button.set_group( group )
        button.set_active( active )

        return button

    def renderSpinButton( self, box, adjustment=[0.0, 0.0, 99.0, 1.0, 10.0, 0.0], climb_rate=0, digits=0, packing=[False, False], align=None, callbacks={}, active=False ):
        """
        Render CheckButton 

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param adjustment: Adjustment of spin button 
        @type  adjustment: list of floats [ value, lower, upper, step_incr, page_incr, page_size ]
        @param climb_rate: the acceleration factor
        @type  climb_rate: C{integer}
        @param digits: the number of decimal places to display
        @type  digits: C{integer}
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        @param align: list of align properties
        @type  align: list of integers [C{integer}, C{integer}, C{integer}, C{integer}]
        @param callbacks: dictionary of signals and functions [dictionary]
        @type  callbacks: C{dictionary}
        @param active: If the button is checked
        @type  active: C{boolean}
        @rtype: gtk.Button or gtk.RadioButton or gtk.ToggleButton
        @todo: box
        """


        button = self.renderButton( box, type="spin", packing=packing, align=align, callbacks=callbacks )
        adjustment = gtk.Adjustment( adjustment[0], adjustment[1], adjustment[2], adjustment[3], adjustment[4], adjustment[5] )
        button.configure( adjustment, climb_rate, digits )
        button.set_wrap( False )

        return button

    def renderToolButton( self, label, icon=None, callbacks={}, sensitive=True, type=None ):
        """
        Render Button or ToggleButton or RadioButton as ToolButtons

        @param label: the button label
        @type  label: C{string}
        @param icon: string (gtk.STOCK*) of button icon 
        @type  icon: C{gtk.STOCK*}
        @param callbacks: dictionary of callbacks with signals as keys and function pointers as data
        @type  callbacks: dictionary
        @param sensitive: sensitivity of button (optional)
        @type  sensitive: C{boolean}
        @param type: type of button ("Toggle",..) - do not use by default. Better to use:
            >>> renderToggleToolButton( label, icon, callbacks, .. )
            >>> renderRadioToolButton( label, icon, callbacks, .. )
        @type  type: specific C{string}
        """

        if type == "Toggle": toolButton = gtk.ToggleToolButton( ) 
        else: toolButton = gtk.ToolButton( ) 

        if icon != None: toolButton.set_icon_widget( self.setIconStock( icon ) )
        toolButton.set_label( label )
        for key in callbacks.keys(): 
            toolButton.connect( key, callbacks[key] )
        toolButton.set_sensitive( sensitive )

        toolButton.show()

        return toolButton

    def renderToggleToolButton( self, label, icon=None, callbacks={}, sensitive=True ):
        """
        Render ToggleButton as ToolButton
        Calling function renderToolButton

        @param label: the button label
        @type  label: C{string}
        @param icon: string (gtk.STOCK*) of button icon 
        @type  icon: C{gtk.STOCK*}
        @param callbacks: dictionary of callbacks with signals as keys and function pointers as data
        @type  callbacks: dictionary
        @param sensitive: sensitivity of button (optional)
        @type  sensitive: C{boolean}
        """

        return self.renderToolButton( label, icon, callbacks, sensitive, type="Toggle" )

    def renderFrame( self, label, label_align=[0,0.5], markup=True, shadow=gtk.SHADOW_ETCHED_IN ):
        """
        Render frame with label as parameter

        @param label: label of the frame
        @type  label: C{string}
        @param label_align: list of label align properties
        @type  label_align: list of integers [C{integer}, C{integer}]
        @param markup: If the label is markup-sensitive
        @type  markup: C{boolean}
        @param shadow: type of the frame line-shadow 
        @type  shadow: C{gtk.SHADOW*}
        """

        # render fram ewith label - label
        frame = gtk.Frame( )
        frame.set_label( '  '+label+'  ' )
        frame.set_label_align( label_align[0], label_align[1] )
        frame.get_label_widget( ).set_use_markup( markup )
        frame.set_shadow_type( shadow )
        frame.show( )
        
        #frame.get_alignment_widget( ).set_padding( 5, 5, 10, 0 )
        alignment, box = self.renderVBox( None, [5, 5, 10, 0] )
        frame.add( alignment )

        return frame, box

    def renderEntry( self, box=None, max=0, packing=[True, True] ):
        """
        Render entry 

        @param box: box to be packed in
        @type  box: C{gtk.VBox} or C{gtk.HBox} or C{None}
        @param max: the maximum length of the entry or 0 for no maximum
        @type  max: C{integer}
        @param packing: packing for box
        @type  packing: ouple of boolean values [C{boolean}, C{boolean}]
        """

        entry = gtk.Entry( max )
        entry.show( )

        if box != None: box.pack_start( entry, packing[0], packing[1], 0 )

        return entry
