#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import stock python libraries
import sys
import gettext
_ = gettext.gettext

# Import GTK and PyGTK libraries
import pygtk
pygtk.require( "2.0" )

import gtk
import gtk.glade
from guiRender import PrimitiveObjects

class exitDialog( PrimitiveObjects ):
    """
        Class that describes main application window.
    """

    def __callback(self, widget):
        self.window.destroy( )
        return self.combo.get_active()

    def __close_application(self, widget, event, data=None):
        self.window.hide( )
        return 3

    def __init__( self, parent, new, old ):

        self.window = self.renderDialogWindow( parent, _("Please choose ..."), 300, 250, resizable=True, modal=True, callbacks={"delete_event": self.__close_application} )
        
        box = self.renderVBox( self.window.vbox, packing=[True, True] )

        #: If you change this, you have to change numbers in __close_application and in configParser !!!
        offer = [ 'Save configuration and exit',
                  'Save configuration, restart server and exit',
                  'Don\'t save configuration and exit',
                  'Back to main window'
                ]

        self.combo = self.renderComboBox( box, align=[10,10,10,10], list=offer, packing=[False, False] )
        self.combo.set_active( 0 )

        liststore = gtk.ListStore( str, str, str )
        mainList = self.renderTreeView( None, liststore, selection_type=gtk.SELECTION_NONE, enable_tree_lines=True )

        self.renderTreeViewColumnText( mainList, _("Option"), 0, expand=True, sort=True )
        self.renderTreeViewColumnText( mainList, _("Old"), 1, sort=True )
        self.renderTreeViewColumnText( mainList, _("New"), 2, sort=True )

        sc = self.renderScrolledWindow( box, mainList )
        for variable in new.keys():
            mainList.get_model().append( [variable, `old[variable]`, `new[variable]`] )

        button = self.renderButton( self.window.action_area, label=_("OK"), packing=[True, True], callbacks={"clicked": self.__callback} )
        button.set_flags(gtk.CAN_DEFAULT)

        button.grab_default()
        self.window.show_all()

    def run( self ):

        result = self.window.run()
        self.window.destroy( )

        return self.combo.get_active()
