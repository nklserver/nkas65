#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

import re
import os
import gtk

from shell import Shell


class Log:
 
    """
        Class, which parse xferlog file to dictionary.
    """

    @staticmethod
    def loadFile( config ):
        shell = Shell()

        if shell.exists( config["xferlog_file"] ):
            handle, file = os.popen2('cat '+config["xferlog_file"])
        else: 
            return None
        return file


    def __init__( self, config ):

        """
            Constructor, make main structure self.dict from xferlog
        """
        self.dict = None

    def parse( self, day, ip ):
        
        """
            Parsing function used to parse lines from self.dict structure
        """

        regexp = re.compile( r"(\d\d\:\d\d\:\d\d )" # Time                  ----
                             r"(\d+ )"              # Transfer time
                             r"([-a-zA-Z0-9\.]+ )"  # hostname or IP        ----
                             r"(\d+ )"              # Transfer bytes
			                 r"(.*)"		    # other
			                 )

        reg2exp = re.compile( r"([c,i])"             # completion status
                            r"( .+)"               # auth user_id
                            r"( [-a-zA-Z0-9]+)"    # authentification
                            r"( [a-z]+)"           # service name
                            r"( [a-zA-Z0-9\?\@]*)"     # identification of user
                            r"( [ar])"             # access mode anonymous/real
                            r"( [io])"             # direction of transfer ----
                            r"( .)"                # special flag
                            r"( [ab])"             # transfer type     
                            r"(.*)"               # filename              ----
                            )
        ret = []

        for line in self.dict[ day ][ ip ]:
            final_part1 = regexp.findall( line )
            exp = final_part1[0][-1][::-1]
            result2 = reg2exp.findall( exp )
            result2[0] = result2[0][::-1]
            
            final_part2 = []
            
            for item in result2[0]:
                final_part2.append(item[::-1])
            
            result = list(final_part1[0][:4]) + final_part2            
            
            if len( result ) != 0: ret.append( result )
        return ret

    def get_month_number( self, month ):

        """

        """

        __month_strings = { 
                "Jan" : 1,
                "Feb" : 2,
                "Mar" : 3,
                "Apr" : 4,
                "May" : 5,
                "Jun" : 6,
                "Jul" : 7,
                "Aug" : 8,
                "Sep" : 9,
                "Oct" : 10,
                "Nov" : 11,
                "Dec" : 12
                          }

        return __month_strings[ month ]

    def get_number_month( self, month ):

        """

        """

        __month_strings = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec" ]

        return __month_strings[ month-1 ]

    def parse_date( self, date ):

        __day_Exp = re.compile ( r"(?P<day>(\d)?\d)"
                                 r"\."
                                 r"(?P<month>[-a-zA-Z]+)"
                                 r"\."
                                 r"(?P<year>\d\d\d\d)" )
        
        __res = __day_Exp.search( date )

        return int(__res.group('day')), int(self.get_month_number(__res.group('month'))), int(__res.group('year'))

