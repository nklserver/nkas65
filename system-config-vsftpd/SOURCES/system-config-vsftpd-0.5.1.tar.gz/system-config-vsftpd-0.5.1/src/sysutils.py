#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import GTK and PyGTK libraries
import gtk

# Import stock python libraries
import re
import os
import sys

from confChoice import chooseConfig
import threading
import gettext
_ = gettext.gettext


class Error:

    @staticmethod
    def PErrorMessageBox( num, message ):
        gtk.MessageDialog( None, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_OK, '(%d) %s' % (num, message) ).run( )
    
    @staticmethod
    def PErrorConsole( num, message ):
        
        mtype = [_("[System Error]")+" ", ""][ num < 500 ]
        sys.stderr.write( "%s(%d) %s\n" % (mtype, num, message) )


class OSUtils:

    @staticmethod
    def openFile( ):
        """Function used for file choooser dialog to select any file"""

        file_open = gtk.FileChooserDialog(title=_("Select Configuration File")
                                        , action=gtk.FILE_CHOOSER_ACTION_SAVE
                                        , buttons=(gtk.STOCK_CANCEL
                                        , gtk.RESPONSE_CANCEL
                                        , gtk.STOCK_OK
                                        , gtk.RESPONSE_OK))
        
        """Create and add the 'all files' filter"""
        filter = gtk.FileFilter()
        filter.set_name(_("All files"))
        filter.add_pattern("*")
        file_open.add_filter(filter)
        
        """Init the return value"""
        result = ""
        if file_open.run() == gtk.RESPONSE_OK:
            result = file_open.get_filename()
        file_open.destroy()
        if result != "": return result

    @staticmethod
    def openDir( ):
        """Function used for file chooser dialog to select directory"""

        dir_open = gtk.FileChooserDialog(title=_("Select Directory")
                                    , action=gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER
                                    , buttons=(gtk.STOCK_CANCEL
                                    , gtk.RESPONSE_CANCEL
                                    , gtk.STOCK_OK
                                    , gtk.RESPONSE_OK))
        
        """Init the return value"""
        result = ""
        if dir_open.run() == gtk.RESPONSE_OK:
            result = dir_open.get_filename()
        dir_open.destroy()
        if result != "": return result


class LogsLoader( threading.Thread ):

    def __init__( self, file, transferLog ):
        
        threading.Thread.__init__(self)
        self.transferLog = transferLog
        self.file = file

    def run( self ):

        dict = {}
        __ip_exp = re.compile( 
                r"(?P<unk>\d*\ )"
                r"(?P<ip>[-a-zA-Z0-9\.]+)")

        fileLines = self.file.readlines()
        step = (100/len( fileLines ))/100.0
        if step == 0.0: #: too much lines we need alternative counter
            step = len( fileLines )/100.0
        count = 0
        done = 0

        for line in fileLines:
            if done > step: 
                count += 1
                done = 0
                gtk.gdk.threads_enter()
                self.transferLog.updateProgressBar( count )
                gtk.gdk.threads_leave()
            day = `int( line[8:10] )` +'.'+ line[4:7] +'.'+ line[20:24]
            if not day in dict:
                dict[ day ] = {}
            ip = __ip_exp.match( line[25:] ).group('ip')
            if not  ip in dict[ day ]:
                dict[ day ][ ip ] = []
            dict[ day ][ ip ].append( line[11:20] + line[25:] )
            done += 1
        gtk.gdk.threads_enter()
        self.transferLog.updateProgressBar( 100, dict )
        gtk.gdk.threads_leave()
                       

class System:

    def __define_config_path( self ):

        Error.PErrorMessageBox( 501, _("I can't read the configuration file.\n Try to check permissions,...") )
        Error.PErrorMessageBox( 501, _('File')+" "+self.cname+" "+_('does not exists!') )

    def find_config( self, parent ):

        """
        Methode for loading configuration from server's configuration file
        """

        confname = "vsftpd.conf"
            # write locations of vsftpd.conf by priority to _paths_ 
        paths = ( "/etc", "/etc/vsftpd", "/usr/local/etc" )
        confList = []

        for path_segment in paths:

            current_path = os.path.join( path_segment, confname )
            if current_path != None and len(current_path) > 0 and os.path.exists( current_path ): 
                try:
                    confFile = open( current_path, 'r')
                except IOError:
                    continue;
                else:
                    confList.append( current_path )
                    confFile.close( )

        if confList == []:
            # No configuration file found
            self.__define_config_path( )
        elif len( confList ) > 1:
            # Found multiple configuration files
            choice = chooseConfig( parent, _confList )
            return choice.run() 
        else: 
            # Found one file, returning..
            return confList[0]



