#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import stock python libraries
import gettext
_ = gettext.gettext
import os
import sys

# Import GTK and PyGTK libraries
import pygtk
pygtk.require( "2.0" )

import gtk
try:
    import gtk.glade
except RuntimeError, e:
    print "system-config-vsftpd:", e
    print _("This is a graphical application and requires DISPLAY to be set.")
    sys.exit (1)

if len(sys.argv)>1 and sys.argv[1] == '--help':
    print ("\n"+_("This is system-config-vsftpd, a VSFTPD server configuration program.")+"\n"\
            +_("For run write: python main.py")+"\n")
    sys.exit (0)


import gnome
import gnome.ui
import threading

# Import application classes
import render
import futils
import shell
import sysutils as _sys

from shell  import Shell
from configParser import Configuration


class MainWindow:
    """
        Class that describes main application window.
    """

    __LOCAL = False

    def __init__( self, config=None ): 

        gnome.init("system-config-vsftpd", "1.0")

        self.shell = shell.Shell( None )


        if self.__LOCAL == True:
            __pixmaps = ""
            __scv_dir = ""
        else:
            __pixmaps = "/usr/share/pixmaps/system-config-vsftpd/"
            __scv_dir = "/usr/share/system-config-vsftpd/"

        self.__ico_path = __pixmaps + "ico/"
        
        # Set up basic info about the program
        self.program_name    = "System-config-vsftpd"
        self.version         = "0.5.0"
        self.description     = _("A configuration tool for Very secure FTP server")
        self.copyright       = "(C) 2007"
        self.authors         = ["Maros Barabas <mbarabas@redhat.com>"]

        gnome.init( self.program_name, self.version )

        self.glade_file = __scv_dir + "system-config-vsftpd.glade"
        #self.glade_file = "system-config-vsftpd.glade"
        self.xml_file   = gtk.glade.XML( self.glade_file, "mainWindow" )
        self.window     = self.xml_file.get_widget( "mainWindow" )
        self.mainTree   = self.xml_file.get_widget( "mainTree" )
        self.appbar     = self.xml_file.get_widget( "appbar" )
        self.mainBox    = self.xml_file.get_widget( "mainBox" )
        self.scWindow   = self.xml_file.get_widget( "scWindow" )
        self.new        = self.xml_file.get_widget( "new1")
        self.open       = self.xml_file.get_widget( "open1" )
        self.save       = self.xml_file.get_widget( "save1" )
        self.reload     = self.xml_file.get_widget( "reload1" )

        self.new.set_sensitive( 0 )
        self.open.set_sensitive( 0 )

        # Handle 
        handlers = { "on_mainWindow_destroy" : self.mainWindow_destroy,
                     "on_save1_activate"     : self.on_save,
                     "on_reload1_activate"   : self.on_reload,
                     "on_open1_activate"     : self.on_open,
                     "on_quit1_activate"     : self.mainWindow_destroy,
                     "on_about1_activate"    : self.renderAbout
                   }
        self.xml_file.signal_autoconnect( handlers );

        # check configuration file and load it
        if not self.loadConfiguration( config ): 
            _sys.Error.PErrorConsole( -1, _("You must be root to run this program !") )
            sys.exit( -1 )

        # render left menu
        self.renderMenu( )

        # call first menu item function to display General tab
        self.AC = render.General( self.mainBox, self.config, self.appbar )

        #self.save.set_sensitive( False )
        #self.reload.set_sensitive( False )

        # 
        self.renderMain( '0' )

    def loadConfiguration( self, config=None ):

        """
            Function to load file, check permissions and user privileges and call configuration parser
        """

        if not self.checkRules( ): return False

        # load configuration file by parser

        self.cname = _sys.System().find_config( self.window )

        self.config = Configuration( self.cname, config )
        if self.config.new == None: return False
        return True

    def checkRules( self ):

        """
            Function to check, if file exists and user has privilages to write to
        """

        # check for root 
        if not self.shell.isRoot( ): 
            return False

        #if not self.shell.exists( self.cname ): 
        #    _sys.Error.PErrorMessageBox( 502, 'File '+self.cname+' does not exists!' )
        #    return False

        return True

    def renderMain( self, rowSelector ):

        """
            Function called, when main window is goin to change by menuRowActivate function
        """

        if self.AC: self.AC.die( self )

        self.AC = {
                '0': lambda result : render.General( self.mainBox, self.config, self.appbar ),
                '1': lambda result : render.ServerControl( self.mainBox, self.config ),
                '2': lambda result : render.AccessControl( self.mainBox, self.config, self.appbar ),
                '3': lambda result : render.UsersControl( self.mainBox, self.config, self.appbar ),
                '4': lambda result : render.DirectoryOptions( self.mainBox, self.config, self.appbar ),
                '5': lambda result : render.Logging( self.mainBox, self.config, self.appbar ),
                '6': lambda result : render.NetworkOptions( self.mainBox, self.config, self.appbar ),
                '7': lambda result : render.TransferLog( self.mainBox, self.config, self.appbar )
        } [ rowSelector ]( self.AC )
        

    def renderMenu( self ):
        
        """
            Function to render left menu
        """

        # create tree model of renderMenu ( left panel )
        self.liststore = gtk.ListStore( str, gtk.gdk.Pixbuf, str )
        self.mainTree.set_model( self.liststore )
        self.menu = gtk.TreeViewColumn( 'Menu' )
        self.mainTree.append_column( self.menu )

        # to know about rows selecting
        self.menuTreeSelection = self.mainTree.get_selection( )
        self.menuTreeSelection.connect( 'changed', self.menuRowActivate )

        # create pictures from files from "ico" directory
        __general_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"monitor.png")
        __server_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"server.png")
        __access_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"access.png")
        __users_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"users.png")
        __directory_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"directory.png")
        __network_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"network.png")
        __logging_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"logging.png")
        __log_ico = gtk.gdk.pixbuf_new_from_file(self.__ico_path+"log.png")


        # create the TreeView using treestore

        self.liststore.append( [ "gnome-stock-blank", __general_ico, _('General')] )
        self.liststore.append( ["gnome-stock-blank", __server_ico, _('Server Control')] )
        self.liststore.append( ["gnome-stock-blank", __access_ico, _('Access Control')] )
        self.liststore.append( ["gnome-stock-blank", __users_ico, _('Users')] )
        self.liststore.append( ["gnome-stock-blank", __directory_ico, _('Directory Options')] )
        self.liststore.append( ["gnome-stock-blank", __logging_ico, _('Logging')] )
        self.liststore.append( ["gnome-stock-blank", __network_ico, _('Network Options')] )
        self.liststore.append( ["gnome-stock-blank", __log_ico, _('Transfer log')] )
        

        self.cellpb  = gtk.CellRendererPixbuf( )
        self.cellpb1 = gtk.CellRendererPixbuf( )
        self.cell    = gtk.CellRendererText( )

        self.menu.pack_start( self.cellpb, False )
        self.menu.pack_start( self.cellpb1, False )
        self.menu.pack_start( self.cell, True )

        self.menu.set_attributes( self.cellpb, stock_id=0 )
        self.menu.set_attributes( self.cellpb1, pixbuf=1 )
        self.menu.set_attributes( self.cell, text=2 )

    def renderAbout(self, widget):

        """
            Function called when clicked on Help->About
        """

        aboutDlg = gnome.ui.About(self.program_name,
                self.version, self.copyright, self.description, self.authors)
        aboutDlg.show()

    def menuRowActivate( self, widget ):

        """
            Function called, when clicked on the left menu
        """

        ( model, iter ) = self.menuTreeSelection.get_selected( )
        if iter:
            self.renderMain( model.get_string_from_iter( iter ) )

    def on_save( self, widget ):

        """
            Called, when clicked on save button from application menu
        """

        self.config.saveConfig( self.window )

    def on_reload( self, widget ):

        """
            Called, when clicked on load button from application menu
        """

        self.config.loadConfig( "/etc/vsftpd/vsftpd.conf" )
        self.menuRowActivate( None )

    def on_open( self, widget ):

        """
            Called, when clicked on opn button from application menu
        """

        confFile = futils.openFile( )
        if confFile: self.cname = confFile
        if not self.loadConfiguration( ): 
            self.cname = self.default
            self.loadConfiguration( )
        self.renderMain( '0' )

    def get_parent( self ):

        """
            Function to get window for parent-> child reasons
        """
        return self.window

    def mainWindow_destroy( self, widget ):
        
        """
            Called when the user closes the main window 
        """

        config = self.config.saveConfig( self.window )
        if config == None:
            gtk.main_quit( )
            sys.exit( 0 )
        else: run( config )

def run( config=None ):
        """
        Start main program loop and load i18n strings
        """
        gtk.gdk.threads_init()
        domain = "system-config-vsftpd"
        gettext.bindtextdomain(domain)
        gettext.textdomain(domain)
        gtk.glade.bindtextdomain (domain)
        gtk.glade.textdomain (domain)
        
        MainWindow( config )
        gtk.main()

if __name__ == "__main__":
    run()
