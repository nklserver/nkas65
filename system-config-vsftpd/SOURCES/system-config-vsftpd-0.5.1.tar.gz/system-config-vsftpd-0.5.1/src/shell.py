#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import libraries
import string
import commands
import os

from sysutils import Error

class Shell:

    """
        Class that describes functions for communicating with shell by commands module.
    """

    def __init__( self, config=None ): 
        """
            Constructor of Shell module, checks status of server
        """
        self.config = config
        # Set up basic info about the program
        self.status = commands.getstatusoutput( '/etc/init.d/vsftpd status' )

    def isRoot( self ):
        """ Function check, if user is root """

        output = commands.getoutput( 'id' )
        list = string.split( output, ' ' )
        dict = {}
        for item in list:
            list2 = string.split( item, '=' )
            dict[ list2[0] ] = list2[1]

        if dict[ 'uid' ][0] == '0': return True
        else: return False

    def stopServer( self ):
        """ Function to stop server """

        output = commands.getoutput( '/etc/init.d/vsftpd stop' )
        return output

    def startServer( self ):
        """ Function to start server """

        output = commands.getoutput( '/etc/init.d/vsftpd start' )
        return output

    def restartServer( self ):
        """ Function to restart server """

        output = commands.getoutput( '/etc/init.d/vsftpd condrestart' )
        return output

    def exists( self, file ):
        """ Function to check if file (see parameter) exists """

        if file != None and len(file) > 0 and os.path.exists( file ): return True
	else: return False

    def getActuall( self ):
        """ Function to get count of actuall connected users"""

        return commands.getoutput( 'netstat -pne | grep vsftpd | grep STREAM | awk \'{print $8}\' | uniq | wc -l' )

    def getLogs( self ):
        """ Function to get logs """

        # TODO - correct non default path to logs
        
        if not self.config: 
            Error.PErrorMessageBox( 256,_("[ E001 ] Configuration error in shell module ") )

        if self.exists( self.config["vsftpd_log_file"] ):
            stdlog = commands.getoutput( 'cat ' + self.config["vsftpd_log_file"] )
        else: stdlog = ""
        if self.exists( self.config["xferlog_file"] ):
            xferlog = commands.getoutput( 'cat ' + self.config["xferlog_file"] )
        else: xferlog = ""
        #xferlog = ""
        syslog = commands.getoutput( 'cat /var/log/messages''* | grep vsftpd' )

        return stdlog, xferlog, syslog

    def _htpasswd_exists( self ):

        raise NotImplementedError

