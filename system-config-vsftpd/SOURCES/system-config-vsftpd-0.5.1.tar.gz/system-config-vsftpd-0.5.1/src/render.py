#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import GTK and PyGTK libraries
import gtk
import gettext
_ = gettext.gettext

import string

from shell import Shell

import futils
import sysutils as _sys
from guiRender import PrimitiveObjects
import logs

class renderMainWindow( PrimitiveObjects ):
    
    """
        Class that describes functions for all render options
    """

    def __init__( self, mainBox, config, appbar=None ):

        #self.ico_path="ico/"
        self.ico_path="/usr/share/pixmaps/system-config-vsftpd/ico/"

        self.mainBox = mainBox
        self.config = config
        self.appbar = appbar
        self.startFlag = True
        self.generalFunctions = [ self.change, self.mouseOver, self.mouseEnd ]

        self.build()
        self.fill()
        self.add_mouse_hints( )
        mainBox.show( ) 

    def die( self, parent ):

        """ Clean all rendered data """
        parent.mainBox.destroy()
        parent.scWindow.destroy()

        parent.scWindow = gtk.ScrolledWindow( )
        parent.scWindow.set_border_width( 0 )
        parent.scWindow.set_policy( gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC )
        parent.scWindow.show( )

        parent.mainBox = gtk.VBox( False, 0 )
        parent.xml_file.get_widget( "mainAlignment" ).add( parent.scWindow )

        alignment = gtk.Alignment( 0, 0, 1, 1 )
        alignment.set_padding( 10, 10, 10, 10 )
        alignment.add( parent.mainBox )
        alignment.show( )
       
        parent.scWindow.add_with_viewport( alignment )

    def mouseOver( self, widget, value ):

        """ Called whhen mouse enter widget """

        if widget in self.mouseHints: self.appbar.set_status( self.mouseHints[widget] )

    def mouseEnd (self, widget, value ):

        """ Called, when mouse leave widget """

        self.appbar.set_status( '' )

    def fill ( self ):

       raise NotImplementedError

    def change ( self ):

       raise NotImplementedError

class General( renderMainWindow ):

    """
        Class that describes functions for render "General" window
    """

    def __init__( self, mainBox, config, appbar ): 
        """ Constructor that renders all widgets """
        
        renderMainWindow.__init__( self, mainBox, config, appbar )
        # end of rendering 
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"monitorH.png", _('General'), 
                _('The following is a list of directives which control the overall behavior of the vsftpd daemon') )
        # --------------------------------------------------------------------------------------- #

        # CheckBox "Use TCP Wrappers
        self.chGeneralUseTCPWrappers = self.renderCheckButton( self.mainBox, _('Use TCP wrappers '), active=False )
        futils.makeConnect( self.chGeneralUseTCPWrappers, self.generalFunctions )
	self.downloadEnable = self.renderCheckButton( self.mainBox, _('Enable download files'), active=True )
        futils.makeConnect( self.downloadEnable, self.generalFunctions )
	self.uploadEnable = self.renderCheckButton( self.mainBox, _('Enable upload files'), active=True )
        futils.makeConnect( self.uploadEnable, self.generalFunctions )

        # Separator
        self.renderHSeparator( self.mainBox, [5, 5, 0, 0], packing=[False,False] )

        # Radio button "Run in standalone mode" with frame "Protocol Settings"
        self.rGeneralStandaloneMode = self.renderRadioButton( self.mainBox, _('Run server in standalone mode'), active=False  )
        futils.makeConnect( self.rGeneralStandaloneMode, [ self.__standalone_toggled ] + self.generalFunctions[1:] )

        # frame - Protocol settings
        frameBox = self.renderHBox( self.mainBox, [5, 5, 25, 5] )
        [self.frame, box] = self.renderFrame( _('Protocol Settings') )
        frameBox.pack_start( self.frame, True, True, 0 )

        # box for ComboBoxEntry with IPv4 or IPv6 option
        box1 = self.renderHBox( box, [0, 8, 0, 0] )
        self.cbGeneralStandaloneProtocol = self.renderComboBox( box1, callbacks={ "changed": self.change }, list=['IPv4\t\t\t\t\t', 'IPv6'], packing=[True, False] )

        # Radio button "Do not run in standalone mode" i group with "Run in standalone mode"
        self.rGeneralNotStandaloneMode = self.renderRadioButton( self.mainBox, _('Do not run in standalone mode'), group=self.rGeneralStandaloneMode, active=False )
        futils.makeConnect( self.rGeneralNotStandaloneMode, [ None] + self.generalFunctions[1:] )

    def __standalone_toggled( self, widget ):
        """Called when one of standalone radiobuttons toggled"""

        self.frame.set_sensitive( self.rGeneralStandaloneMode.get_active( ) )
        self.cbGeneralStandaloneProtocol.set_sensitive( self.rGeneralStandaloneMode.get_active( ) )

        # Change settings in config
        if self.rGeneralStandaloneMode.get_active( ) == False: 
            self.config["listen"] = "NO"
            self.config["listen_ipv6"] = "NO"
        elif self.cbGeneralStandaloneProtocol.get_active_text( ).strip == "IPv4":
            self.config["listen"] = "YES"
            self.config["listen_ipv6"] = "NO"
        else: 
            self.config["listen"] = "NO"
            self.config["listen_ipv6"] = "YES"

    def add_mouse_hints( self ):

        self.mouseHints = { 
             self.chGeneralUseTCPWrappers     : _('Use TCP wrappers to grant access to the server.'),
             self.downloadEnable              : _('Enable download files from server'),
             self.uploadEnable                : _('Enable upload files. ( see in Users -> Anonymous users -> Allow upload files )'),
             self.rGeneralStandaloneMode      : _('Run vsftpd in standalone mode.'),
             self.rGeneralNotStandaloneMode   : _('Do not run in standalone mode.')
        }

    def fill( self ):
        """ Function to fill widgets with values from configuration  """

        self.chGeneralUseTCPWrappers.set_active( self.config["tcp_wrappers"] == "YES" )
        self.downloadEnable.set_active( self.config["download_enable"] == "YES" )
        self.uploadEnable.set_active( self.config["write_enable"] == "YES" )
        self.cbGeneralStandaloneProtocol.set_active( self.config["listen_ipv6"] == "YES" ) 
        self.rGeneralNotStandaloneMode.set_active( self.config["listen"] == "NO" and self.config["listen_ipv6"] == "NO" )

    def change( self, widget, object=None ):
        """ Function called when user change some value on the form """

        if self.startFlag: return
        if   widget == self.downloadEnable:  
		if self.downloadEnable.get_active( ): self.config["download_enable"] = "YES"
		else: self.config["download_enable"] = "NO"
        elif widget == self.uploadEnable:  
		if self.uploadEnable.get_active( ): self.config["write_enable"] = "YES"
		else: self.config["write_enable"] = "NO"
        elif widget == self.chGeneralUseTCPWrappers:
            print "aaa"
            if widget.get_active( ) == True: self.config["tcp_wrappers"] = "YES"
            else: self.config["tcp_wrappers"] = "NO"
        elif widget == self.cbGeneralStandaloneProtocol:
            if self.cbGeneralStandaloneProtocol.get_active_text( ).strip() == "IPv4" and self.rGeneralStandaloneMode.get_active( ):
                self.config["listen"] = "YES"
                self.config["listen_ipv6"] = "NO"
            elif self.rGeneralStandaloneMode.get_active( ): 
                self.config["listen"] = "NO"
                self.config["listen_ipv6"] = "YES"
            else:
                self.config["listen"] = "NO"
                self.config["listen_ipv6"] = "NO"


class ServerControl( renderMainWindow ):

    """
        Class that describes functions for render "Server Control" window
    """

    def __init__( self, mainBox, config ): 
        """ Constructor that render all widgets  """

        self.shell = Shell( config )

        renderMainWindow.__init__( self, mainBox, config )
        # end of rendering
        self.__logs( )
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"serverH.png", _('Server Control'), _('Service control management') )
        # --------------------------------------------------------------------------------------- #


        # frame - Server Status
        [frame, box] = self.renderFrame( 'Server status' )
        self.mainBox.pack_start( frame, False, True, 0 )

        # box for ComboBoxEntry with IPv4 or IPv6 option
        box1 = self.renderHBox( box, [0, 10, 0, 0] )
        box2 = self.renderVBox( box1, [0, 0, 0, 0] )
        box3 = self.renderHBox( box1, [15, 15, 100, 0] )

        self.lServerStatus = self.renderLabel( box2, '', markup=True, padding=[5, 0] )
        self.lServerAction = self.renderLabel( box2, '', markup=True, padding=[10, 10] )
        self.bServerAction = self.renderButton( box1, callbacks={"pressed": self.__status_toggled } )

        # get the status of the server
        self.__status( )

        # horizontal separator
        self.renderHBox( self.mainBox, [5, 5, 0, 0] )

        # render notebook
        self.logNotebook = self.renderNoteBook( self.mainBox )

        # render first log with status when pressed button to start / stop server
        # --------------------------------------------------------------------------------------------
        self.statusBox = self.renderNBPage( self.logNotebook, _('Status Log'), align=[10, 10, 10, 10], markup=False  )
        self.renderLabel( self.statusBox, "<i>"+_("This log shows all messages during server startup or stop")+"</i>", markup=True, line_wrap_mode=gtk.WRAP_NONE, padding=[0, 0] )
        # horizontal separator
        self.renderHBox( self.statusBox, [5, 5, 0, 0] )
        self.twServerStatus = self.renderTextView( self.statusBox )

        # render standard log ( /var/log/vsftpd.log )
        # --------------------------------------------------------------------------------------------
        self.logBox = self.renderNBPage( self.logNotebook, _('Standard Log'), align=[10, 10, 10, 10], markup=False  )
        self.renderLabel( self.logBox, "<i>"+_("This log shows all standard logs from vsftpd")+"</i>", markup=True, line_wrap_mode=gtk.WRAP_NONE, padding=[0, 0] )
        # horizontal separator
        self.renderHBox( self.logBox, [5, 5, 0, 0] )
        self.twServerLog = self.renderTextView( self.logBox )

        # render wu-ftpd compatible log ( /var/log/xferlog )
        # --------------------------------------------------------------------------------------------
        self.xferlogBox = self.renderNBPage( self.logNotebook, _('XFerLog'), align=[10, 10, 10, 10], markup=False  )
        self.renderLabel( self.xferlogBox, "<i>"+_("Wu-ftpd compatible log")+"</i>", markup=True, line_wrap_mode=gtk.WRAP_NONE, padding=[0, 0] )
        # horizontal separator
        self.renderHBox( self.xferlogBox, [5, 5, 0, 0] )
        self.twServerXLog = self.renderTextView( self.xferlogBox )

        # render system log - grep vsftpd from /var/log/messages
        # --------------------------------------------------------------------------------------------
        self.sysBox = self.renderNBPage( self.logNotebook, _('System Log'), align=[10, 10, 10, 10], markup=False  )
        self.renderLabel( self.sysBox, "<i>"+_("System log shows all logs from /var/log/messages which contains 'vsftpd'")+"</i>", markup=True, line_wrap_mode=gtk.WRAP_NONE, padding=[0, 0] )
        # horizontal separator
        self.renderHBox( self.sysBox, [5, 5, 0, 0] )
        self.twServerSysLog = self.renderTextView( self.sysBox )
        #self.renderHBox( self.sysBox, [5, 5, 0, 0] ) #TODO: If I want to show all /var/log/messages* ?
        #self.renderButton( self.sysBox, label="See all" )

        box1 = self.renderHBox( self.mainBox, [5, 0, 0, 0] )
        self.bReloadLogs = self.renderButton( box1, label="  "+_("Reload logs")+"  ", callbacks={"pressed": self.__logs} )

    def __logs( self, widget=None ):

        """ Function to load logs """
        stdlog, xferlog, syslog = self.shell.getLogs( )
        self.twServerLog.get_buffer( ).set_text( stdlog )
        self.twServerXLog.get_buffer( ).set_text( xferlog )
        self.twServerSysLog.get_buffer( ).set_text( syslog )

    def __status( self ):

        """ Function to check server status """
        self.shell.__init__( self.config )
        act = self.shell.getActuall( )
        if act == '1': client = _("client")
        else: client = _("clients")

        # server is running
        if self.shell.status[0]: 
            self.lServerStatus.set_label( "<b>"+_("Server is stopped")+"</b>" )
            self.lServerAction.set_label( "Click this button to start ftp server." )
            self.bServerAction.set_label( "         "+_("Start FTP Server")+"          " )
            self.bServerAction.set_image( gtk.image_new_from_stock( 'gtk-media-play', 3 ) )
        else:
            self.lServerStatus.set_label( "<b>"+_("Server is running")+"</b> ( "+act+" "+client+")" )
            self.lServerAction.set_label( _("Click this button to stop ftp server.") )
            self.bServerAction.set_label( "          "+_("Stop FTP Server")+"          " )
            self.bServerAction.set_image( gtk.image_new_from_stock( 'gtk-stop', 3 ) )

    def __status_toggled( self, widget ):

        """ Function called, wwhen user clicked on start/stop button"""
        # server is not running
        if self.shell.status[0]: 
            message = self.shell.startServer( )
            #start = string.find( message, ":" ) + 2
            #firstSpace = string.find( message, " ", start )
            #secondSpace = string.find( message, " ", firstSpace + 2 )
            #message = message[ 0 : start ] + message[ firstSpace : secondSpace ]
            self.twServerStatus.get_buffer( ).insert( self.twServerStatus.get_buffer( ).get_end_iter(), message+'\n' )
            self.__status( )

        else:
            message = self.shell.stopServer( )
            #start = string.find( message, ":" ) + 2
            #firstSpace = string.find( message, " ", start )
            #secondSpace = string.find( message, " ", firstSpace + 2 )
            #message = message[ 0 : start ] + message[ firstSpace : secondSpace ]
            self.twServerStatus.get_buffer( ).insert( self.twServerStatus.get_buffer( ).get_end_iter(), message+'\n' )
            self.__status( )

        self.__logs( )

    def fill( self ):
        pass

    def add_mouse_hints( self ):
        pass

    def change( self ):
        pass


class AccessControl( renderMainWindow ):

    """
        Class that describes functions for render "Access Control" window
    """

    def __init__( self, mainBox, config, appbar ): 
        """ Constructor that render all widgets  """

        self.shell = Shell( config )

        renderMainWindow.__init__( self, mainBox, config, appbar )
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"accessH.png", _('Access Control'), 
                _('The following is a list of directives which control the login behavior and access control mechanisms') )
        # ------------------------------------------------------------------------------------- #


        # frame with label - Banners
        # ------------------------------------------------------------------------------------- #
        [frame, box] = self.renderFrame( _('Banners') )
        self.mainBox.pack_start( frame, False, True, 0 )

        # Access Banner String ( label with entry )
        box1 = self.renderHBox( box, [0, 0, 0, 10] )

        # [ftp_banner]
        self.rAccessBannerString = self.renderRadioButton( box1, _('Use string :')+' ', active=False )
        futils.makeConnect( self.rAccessBannerString, [ None ] + self.generalFunctions[1:] )
        self.eAccessBannerString = self.renderEntry( box1 ) 
        futils.makeConnect( self.eAccessBannerString, self.generalFunctions )

        # Access Banner File box ( label with entry and button )
        box1 = self.renderHBox( box, [0, 0, 0, 10] )

        # [banner_file]
        self.rAccessBannerFile = self.renderRadioButton( box1, _('Use file :')+'     ', active=False, group=self.rAccessBannerString )
        futils.makeConnect( self.rAccessBannerFile, [ self.__banner_toggled ] + self.generalFunctions[1:] )
        self.eAccessBannerFile = self.renderEntry( box1 )
        futils.makeConnect( self.eAccessBannerFile, self.generalFunctions )
        self.bAccessBannerFile = self.renderButton( box1, label=_('Change...'), callbacks={"pressed": self.change} )

        # horizontal separator
        self.renderHBox( self.mainBox, [5, 5, 0, 0] )

        # frame with label - Email bans
        # ------------------------------------------------------------------------------------- #
        [frame, box] = self.renderFrame( _('Email bans') )
        self.mainBox.pack_start( frame, False, True, 0 )

        # box with email bans file 
        box1 = self.renderHBox( box, [0, 0, 0, 10] )

        # [deny_email_enable]
        self.chAccessEmailBansFile = self.renderCheckButton( box1, _('Define emails not permitted access to the server'), active=True )
        futils.makeConnect( self.chAccessEmailBansFile, [ self.__emailBans_toggled ] + self.generalFunctions[1:] )

        # [banned_email_file]
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eAccessEmailBansFile = self.renderEntry( box1 )
        futils.makeConnect( self.eAccessEmailBansFile, self.generalFunctions )
        self.bAccessEmailBansFile = self.renderButton( box1, label=_('Change...'), callbacks={"pressed": self.change} )

        # horizontal separator
        self.renderHBox( self.mainBox, [5, 5, 0, 0] )

        # frame with label - Local Users
        # ------------------------------------------------------------------------------------- #
        [frame, box] = self.renderFrame( _('Local users') )
        self.mainBox.pack_start( frame, False, True, 0 )

        # [userlist_enable]
        box1 = self.renderHBox( box, [0, 0, 0, 10] )
        self.chAccessEnableUserList = self.renderCheckButton( box1, _('Enable list of allowed / denied users') )
        futils.makeConnect( self.chAccessEnableUserList, [ self.__enableUserList_toggled ] + self.generalFunctions[1:] )

        # [userlist_deny]
        box1 = self.renderHBox( box, [0, 0, 0, 10] )
        self.chAccessEnableDeny = self.renderCheckButton( box1, _('Deny users in the list (otherwise allow)') )
        futils.makeConnect( self.chAccessEnableDeny, [ self.__enableDenyList_toggled ] + self.generalFunctions[1:] )

        # [userlist_file]
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eAccessUserListFile = self.renderEntry( box1 )
        futils.makeConnect( self.eAccessUserListFile, self.generalFunctions )
        self.bAccessUserListFile = self.renderButton( box1, label=_('Change...'), callbacks={"pressed": self.change} )


    def __banner_toggled( self, widget ):

        """Called when radiobuttons in banner site toggled"""
        self.eAccessBannerString.set_sensitive( self.rAccessBannerString.get_active( ) )
        self.eAccessBannerFile.set_sensitive( self.rAccessBannerFile.get_active( ) )
        self.bAccessBannerFile.set_sensitive( self.rAccessBannerFile.get_active( ) )

        # Set Config
        if self.rAccessBannerFile.get_active( ) == True: 
            self.config["ftpd_banner"] = ""
            self.config["banner_file"] = self.eAccessBannerFile.get_text( )
        else: 
            self.config["banner_file"] = ""
            self.config["ftpd_banner"] = self.eAccessBannerString.get_text( )


    def __emailBans_toggled( self, widget ):

        """Called when toggled checkbutton on Email Bans"""
        self.eAccessEmailBansFile.set_sensitive( self.chAccessEmailBansFile.get_active( ) )
        self.bAccessEmailBansFile.set_sensitive( self.chAccessEmailBansFile.get_active( ) )

        # Set Config
        if self.chAccessEmailBansFile.get_active( ) == True: 
            self.config["deny_email_enable"] = "YES"
            self.config["banned_email_file"] = self.eAccessEmailBansFile.get_text( )
        else: self.config["deny_email_enable"] = "NO"
        

    def __enableUserList_toggled( self, widget ):

        """Called when radiobuttons in enable user list toggled"""
        self.chAccessEnableDeny.set_sensitive( self.chAccessEnableUserList.get_active( )  )
        self.eAccessUserListFile.set_sensitive( self.chAccessEnableUserList.get_active( ) )
        self.bAccessUserListFile.set_sensitive( self.chAccessEnableUserList.get_active( ) )

        # Set Config
        if self.chAccessEnableUserList.get_active( ) == True: self.config["userlist_enable"] = "YES"
        else: self.config["userlist_enable"] = "NO"

    def __enableDenyList_toggled( self, widget ):

        """Called when checkbox on Enable deny list get toggled"""
        if self.chAccessEnableDeny.get_active( ) == True: self.config["userlist_deny"] = "YES"
        else: self.config["userlist_deny"] = "NO"

    def add_mouse_hints( self ):

        self.mouseHints = { 
             self.rAccessBannerString    : _('Specified string is displayed when a connection is established to the server.'),
             self.eAccessBannerString    : _('Specified string is displayed when a connection is established to the server.'),
             self.rAccessBannerFile      : _('Specified file containing text displayed when a connection is established to the server.'),
             self.eAccessBannerFile      : _('Specified file containing text displayed when a connection is established to the server.'),
             self.chAccessEmailBansFile  : _('This directive specifies the file containing a list of anonymous email passwords which are not permitted to the server.'),
             self.eAccessEmailBansFile   : _('This file containing a list of anonymous email passwords which are not permitted to the server.'),
             self.chAccessEnableUserList : _('When enabled the users listed in the file below are denied or allowed access to the server ( see Deny users directive below ).'),
             self.chAccessEnableDeny     : _('When enabled the users listed in the file below are DENIED to access to the server, otherwise ALLOWED'),
             self.eAccessUserListFile    : _('This file containing a list of users which are allowed or denied to access to the server depends on directive above')
        }

    def change( self, widget ):

        """ Function called when user change some value on the form """
        choice = None

        if   widget == self.eAccessBannerString:    self.config["ftpd_banner"] = self.eAccessBannerString.get_text( )
        elif widget == self.eAccessBannerFile:    self.config["banner_file"] = self.eAccessBannerFile.get_text( )
        elif widget == self.eAccessEmailBansFile: self.config["banned_email_file"] = self.eAccessEmailBansFile.get_text( )
        elif widget == self.eAccessUserListFile:  self.config["userlist_file"] = self.eAccessUserListFile.get_text( )

        else: choice = _sys.OSUtils.openFile( )

        if choice:
            if   widget == self.bAccessBannerFile:    self.eAccessBannerFile.set_text( choice )
            elif widget == self.bAccessEmailBansFile: self.eAccessEmailBansFile.set_text( choice )
            elif widget == self.bAccessUserListFile:  self.eAccessUserListFile.set_text( choice )

    def fill( self ):

        """ Function to fill widgets with values from configuration  """
        if len(self.config["ftpd_banner"] ) > 0: self.eAccessBannerString.set_text( self.config["ftpd_banner"] )
        if len(self.config["banner_file"] ) > 0:
            self.eAccessBannerFile.set_text( self.config["banner_file"] )
            self.rAccessBannerFile.set_active( True )

        self.chAccessEmailBansFile.set_active( self.config["deny_email_enable"] == "YES" )
        self.eAccessEmailBansFile.set_text( self.config["banned_email_file"] )

        self.chAccessEnableUserList.set_active( self.config["userlist_enable"] == "YES" )
        self.chAccessEnableDeny.set_active( self.config["userlist_deny"] == "YES" )
        self.eAccessUserListFile.set_text( self.config["userlist_file"] )

        self.__enableUserList_toggled( None )
        self.__banner_toggled( None )



class UsersControl( renderMainWindow ):

    """
        Class that describes functions for render "Users" window
    """

    def __init__( self, mainBox, config, appbar ): 
        """ Constructor that render all widgets  """

        self.startFlag = True

        renderMainWindow.__init__( self, mainBox, config, appbar )
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"usersH.png", 'Users', 
                'the following is a list of directives which charakterize the way local and anonymous users access the server.' )
        # ------------------------------------------------------------------------------------- #


        self.usersNotebook = self.renderNoteBook( self.mainBox )

        # Labels for notebook
        virtualLabel = gtk.Label( 'Virtual users' )
        virtualLabel.show( )

        # Local users
        # ------------------------------------------------------------------------------------- #

        # Box for rendering system box
        box = self.renderVBox( )

        self.usersBox = self.renderNBPage( self.usersNotebook, 'System users', align=[10,10,10,10] )
        
        # [local_enable]
        self.chAllowLocalUsers = self.renderCheckButton( self.usersBox, 'Allow local users', active=True )
        futils.makeConnect( self.chAllowLocalUsers, [self.__allowLocalUsers] + self.generalFunctions[1:] )

        # Separator
        self.renderHSeparator( self.usersBox, [5, 5, 0, 0], packing=[False,False] )

        # Render box for user options
        self.renderHBox( self.usersBox, [5, 5, 0, 0] )
        self.systemUsersBox = self.renderVBox( self.usersBox, [0, 0, 0, 0] )
        
        # [chmod_enable]
        self.chUsersChmodEnable = self.renderCheckButton( self.systemUsersBox, 'Allow users to change the permissions on files' )
        futils.makeConnect( self.chUsersChmodEnable, self.generalFunctions )

        # [chroot_local_user]
        self.chUsersChangeRoot = self.renderCheckButton( self.systemUsersBox, 'Change root directory for the users to their home directories' )
        futils.makeConnect( self.chUsersChangeRoot, self.generalFunctions )

        # [?]
        self.chPasswdChRootEnable = self.renderCheckButton( self.systemUsersBox, 'Change root directory based on the occurece of the "." in the home '
                                                                                   'directory field within /etc/passwd' )
        futils.makeConnect( self.chPasswdChRootEnable, self.generalFunctions )

        # Separator
        self.renderHSeparator( self.systemUsersBox, [5, 5, 0, 0], packing=[False,False] )
               
        # frame Chroot jail 
        [frame, box] = self.renderFrame( 'Chroot Jail' )
        self.systemUsersBox.pack_start( frame, False, True, 0 )

        # [chroot_list_enable]
        box1 = self.renderHBox( box, [0, 0, 0, 10] )
        self.chRootListEnable = self.renderCheckButton( box1, 'Place only users from list below to "chroot jail"' )
        futils.makeConnect( self.chRootListEnable, [self.__enableRootList_toggled] + self.generalFunctions[1:] )

        # [chroot_list_file]
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eRootListEnable = self.renderEntry( box1 )
        futils.makeConnect( self.eRootListEnable, self.generalFunctions )
        self.bRootListEnable = self.renderButton( box1, label='Change...', callbacks={"pressed": self.change} )

        # horizontal separator
        self.renderHBox( self.systemUsersBox, [5, 5, 0, 0] )

        # frame with Guest
        [frame, box] = self.renderFrame( 'Guest' )
        self.systemUsersBox.pack_start( frame, False, True, 0 )

        # [guest_enable]
        box1 = self.renderHBox( box, [0, 0, 0, 10] )
        self.chGuestEnable = self.renderCheckButton( box1, 'Change all non-anonymous users logged in to the user:' )
        futils.makeConnect( self.chGuestEnable, [self.__guestEnable_toggled] + self.generalFunctions[1:] )

        # [guest_username]
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eGuestEnable = self.renderEntry( box1 )
        futils.makeConnect( self.eGuestEnable, self.generalFunctions )

        # horizontal separator
        self.renderHBox( self.systemUsersBox, [5, 5, 0, 0] )

        # [local_root]
        self.lLocalRoot = self.renderLabel( box, 'Specify the directory <i>vsftpd</i> changes to after a local user logs in:' )
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eLocalRoot = self.renderEntry( box1 )
        futils.makeConnect( self.eLocalRoot, self.generalFunctions )
        self.bLocalRoot = self.renderButton( box1, label='Change...', callbacks={"pressed": self.change} )

        # horizontal separator
        self.renderHBox( self.systemUsersBox, [5, 5, 0, 0] )

        # [user_config_dir]
        self.lUserConfigDir = self.renderLabel( box, 'Specify the path to a directory containing configuration files bearing the name of local system\n'
                                                    'users that contain specific settings for that user', line_wrap_mode=gtk.WRAP_NONE )
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eUserConfigDir = self.renderEntry( box1 )
        futils.makeConnect( self.eUserConfigDir, self.generalFunctions )
        self.bUserConfigDir = self.renderButton( box1, label='Change...', callbacks={"pressed": self.change} )

        # Separator
        self.renderHSeparator( self.systemUsersBox, [5, 5, 0, 0], packing=[False,False] )

        # [local_max_rate]
        box = self.renderHBox( self.systemUsersBox, [0, 0, 0, 0] )
        label = self.renderLabel( None, 'Maximum data transfer rate (B/s):   ' ) 
        self.sLocalMaxRate = self.renderSpinButton( None, [0.0, 0.0, 999999999.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sLocalMaxRate, self.generalFunctions )

        # [local_umask]
        self.lLocalUmask = self.renderLabel( None, 'Umask for file creation: ' )
        self.eLocalUmask = self.renderEntry( None, 3 )
        futils.makeConnect( self.eLocalUmask, self.generalFunctions )

        # table model
        tableModel = [ [ label, self.sLocalMaxRate ],
                       [ self.lLocalUmask, self.eLocalUmask ] ]

        futils.renderTable( box, tableModel )

        # ------------------------------------------------------------------------------------- #
        # Anonymous user

        # Box for rendering system box
        self.anonymousBox = self.renderNBPage( self.usersNotebook, 'Anonymous user', align=[10,10,10,10] )

        # [anonymous_enable]
        self.chAllowAnonymousUser = self.renderCheckButton( self.anonymousBox, 'Allow anonymous user', active=True )
        futils.makeConnect( self.chAllowAnonymousUser,[self.__allowAnonymousUser] + self.generalFunctions[1:] )
        
        # Separator
        self.renderHSeparator( self.anonymousBox, [5, 5, 0, 0], packing=[False,False] )

        # Render box for anonymous options
        self.renderHBox( self.anonymousBox, [5, 5, 0, 0] )
        self.anonymousUserBox = self.renderVBox( self.anonymousBox, [0, 0, 0, 0] )

        # [anon_mkdir_write_enable]
        self.chAllowCreatingNewDirectories = self.renderCheckButton( self.anonymousUserBox, 'Allow creating new directories' )
        futils.makeConnect( self.chAllowCreatingNewDirectories, self.generalFunctions ) 

        # [anon_upload_enable]
        self.chAllowUploadFiles = self.renderCheckButton( self.anonymousUserBox, 'Allow upload files' )
        futils.makeConnect( self.chAllowUploadFiles, self.generalFunctions ) 

        # [no_anon_password]
        self.chAskForPassword = self.renderCheckButton( self.anonymousUserBox, 'Do not ask for a password' )
        futils.makeConnect( self.chAskForPassword, self.generalFunctions ) 

        # [anon_world_readable_only]
        box1 = self.renderHBox( self.anonymousUserBox, [0, 0, 0, 0] )
        self.chAnonymousWorldOnlyEnable = self.renderCheckButton( box1, 'Allow to download only world-readable files' )
        futils.makeConnect( self.chAnonymousWorldOnlyEnable, self.generalFunctions )

        # [allow_anon_ssl]
        box1 = self.renderHBox( self.anonymousUserBox, [0, 0, 0, 0] )
        self.chAnonymousUseSSL = self.renderCheckButton( box1, 'Allow anonymous to use ssl connection' )
        futils.makeConnect( self.chAnonymousUseSSL, self.generalFunctions )

        # Separator
        self.renderHSeparator( self.anonymousUserBox, [5, 5, 0, 0], packing=[False,False] )
               
        # frame with Changing owner
        [frame, box] = self.renderFrame( 'Changing owner' )
        self.anonymousUserBox.pack_start( frame, False, True, 0 )

        # [chown_uploads]
        box2 = self.renderHBox( box, [0, 0, 0, 10] )
        self.chAnonymousChOwner = self.renderCheckButton( box2, 'Change owner on all uploaded files to user below ' )
        futils.makeConnect( self.chAnonymousChOwner, [self.__chownUploads_toggled] + self.generalFunctions[1:] )
        # Entry with box with path to file
        box2 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eAnonymousChOwner = self.renderEntry( box2 )
        futils.makeConnect( self.eAnonymousChOwner, self.generalFunctions )

        # horizontal separator
        self.renderHBox( self.anonymousUserBox, [5, 5, 0, 0] )
        box = self.renderHBox( self.anonymousUserBox, [0, 0, 0, 0] )

        # [ftp_username]
        self.lAnonymousUserName = self.renderLabel( None, 'FTP user:   ' ) 
        self.eAnonymousUserName = self.renderEntry( None, 30 )
        futils.makeConnect( self.eAnonymousUserName, self.generalFunctions )
        
        (alignment1, box1) = self.renderVBox( None, [5, 5, 0, 0] )

        # [anon_root]
        self.lAnonymousRootDir = self.renderLabel( None, 'Root directory:   ' ) 
        self.eAnonymousRootDir = self.renderEntry( None, 30 )
        futils.makeConnect( self.eAnonymousRootDir, self.generalFunctions )
        self.bAnonymousRootDir = self.renderButton( None, label=' Change... ', callbacks={"pressed": self.change} )

        tableModel = [ [ self.lAnonymousUserName, self.eAnonymousUserName, None ],
                       [ alignment1 ],
                       [ self.lAnonymousRootDir, self.eAnonymousRootDir, self.bAnonymousRootDir ] ]


        futils.renderTable( box, tableModel )

        # Separator
        self.renderHSeparator( self.anonymousUserBox, [15, 15, 0, 0], packing=[False,False] )
               
        # [anon_max_rate]
        self.lAnonymousMaxRate = self.renderLabel( None, 'Maximum data transfer rate (B/s): ' )
        self.sAnonymousMaxRate = self.renderSpinButton( None, [0.0, 0.0, 999999999.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sAnonymousMaxRate, self.generalFunctions )
        
        # [anon_umask]
        self.lAnonUmask = self.renderLabel( None, 'Umask for file creation: ' )
        self.eAnonUmask = self.renderEntry( None, 3 )
        futils.makeConnect( self.eAnonUmask, self.generalFunctions )

        tableModel = [ [ self.lAnonymousMaxRate, self.sAnonymousMaxRate ],
                       [ self.lAnonUmask, self.eAnonUmask ] ]

        futils.renderTable( self.anonymousUserBox, tableModel )

        # Virtual users TODO
        # ------------------------------------------------------------------------------------- #

        # Box for rendering system box
        #self.virtualBox = self.renderNBPage( self.usersNotebook, 'Virtual users', [10, 10, 10, 10] )
        #self.usersNotebook.append_page( box, virtualLabel )

        # [?]
        #self.chAllowVirtualUsers = futils.renderCheckButton( self.virtualBox, 'Allow virtual users', True, self.generalFunctions )
        
        # Separator
        #self.renderHSeparator( self.anonymousBox, [5, 5, 0, 0], packing=[False,False] )

    def __chownUploads_toggled( self, widget ):
        """Called when checkbox on Change owner get toggled"""
        self.eAnonymousChOwner.set_sensitive( self.chAnonymousChOwner.get_active() )

        # Set Config
        if widget == self.chAnonymousChOwner: 
            if widget.get_active( ) == True: self.config["chown_uploads"] = "YES"
            else: self.config["chown_uploads"] = "NO"

    def __enableRootList_toggled( self, widget ):
        """Called when checkbox on enabling root list get toggled"""
        self.eRootListEnable.set_sensitive( self.chRootListEnable.get_active( ) )
        self.bRootListEnable.set_sensitive( self.chRootListEnable.get_active( ) )

        # Set Config
        if widget == self.chRootListEnable: 
            if widget.get_active( ) == True: self.config["chroot_list_enable"] = "YES"
            else: self.config["chroot_list_enable"] = "NO"

    def __guestEnable_toggled( self, widget ):
        """Called when checkbox on enabling guest get toggled"""
        self.eGuestEnable.set_sensitive( self.chGuestEnable.get_active() )

        # Set Config
        if widget == self.chGuestEnable: 
            if widget.get_active( ) == True: self.config["guest_enable"] = "YES"
            else: self.config["guest_enable"] = "NO"

    def __allowLocalUsers( self, widget ):
        """Called when checkbox on allowing local users get toggled"""
        self.systemUsersBox.set_sensitive( self.chAllowLocalUsers.get_active() )

        # Set config
        if widget == self.chAllowLocalUsers: 
            if widget.get_active( ) == True: self.config["local_enable"] = "YES"
            else: self.config["local_enable"] = "NO"

    def __allowAnonymousUser( self, widget ):
        """Called when checkbox on allowing anon users get toggled"""
        self.anonymousUserBox.set_sensitive( self.chAllowAnonymousUser.get_active() )

        # Set config
        if widget == self.chAllowAnonymousUser: 
            if widget.get_active( ) == True: self.config["anonymous_enable"] = "YES"
            else: self.config["anonymous_enable"] = "NO"

    def add_mouse_hints( self ):

        self.mouseHints = { # Local Users
             self.chAllowLocalUsers  : 'Allow local system users to access the server',
             self.chUsersChmodEnable : 'When enabled, the FTP command SITE CHMOD is allowed for local users. This command allows the users to change the permissions on files.',
             self.chUsersChangeRoot  : 'When enabled, local  users are change-rooted to their home directories after logging in.',
             self.chRootListEnable   : 'When enabled, the local users listed in the file specified below are placed in a chroot jail upon log in.',
             self.eRootListEnable    : 'Specifies the file containing a list of local users which are placed in a chroot jail upon log in.',
             self.chGuestEnable      : 'When enabled, all non-anonymous users are logged in as the user guest, which is the local user specified in the entry below.',
             self.eGuestEnable       : 'Specifies the username the guest user is mapped to.',
             self.eLocalRoot         : 'Specifies the directory vsftpd changes to after a local user logs in.',
             self.eUserConfigDir     : 'Specifies the path to a directory containing configuration files bearing the name of local system users that contain specific settings for that user.',
             self.sLocalMaxRate      : 'Specifies the maximum rate data is transfered for local users logged into the server in bytes per second.',
             self.eLocalUmask        : 'Specifies the umask of created files by local users.',
                            # Anonymous User
             self.chAllowAnonymousUser           : 'Allow anonymous users to access the server.',
             self.chAllowCreatingNewDirectories  : 'When enabled, anonymous users are allowed to create nre directories within a parent directory which has write permissions.',
             self.chAllowUploadFiles             : 'Allow anonymous users to upload files to the server.',
             self.chAskForPassword               : 'When enabled, the anonymous user is not asked for a password.',
             self.chAnonymousWorldOnlyEnable     : 'When enabled, anonymous users are only allowed to download world-readable files.',
             self.chAnonymousUseSSL              : 'Allow anonymous to use SSL',
             self.chAnonymousChOwner             : 'When eabled, all files uploaded by anonymous users are owned by the user specified below.',
             self.eAnonymousChOwner              : 'Specifies the ownership of anonymously uploaded files.',
             self.eAnonymousUserName             : 'Specifies the local user account (listed in /etc/passwd) used for the anonymous FTP user.',
             self.eAnonymousRootDir              : 'Specifies the directory vsftpd changes to after an anonymous user logs in.',
             self.sAnonymousMaxRate              : 'Specifies the maximum data transfer rate for anonymous users in bytes per second.',
             self.eAnonUmask                     : 'Specifies the umas of created files by anonymous user.',
                            # Virtual Users
             #self.chAllowVirtualUsers           : 'Allow Virtual users'
        }

    def fill( self ):

        """ Function to fill widgets with values from configuration  """
        # Local Users
        self.chAllowLocalUsers.set_active ( self.config["local_enable"] == "YES" )
        self.chUsersChmodEnable.set_active( self.config["chmod_enable"] == "YES" )
        self.chUsersChangeRoot.set_active ( self.config["chroot_local_user"] == "YES" )
        self.chPasswdChRootEnable.set_active( self.config["passwd_chroot_enable"] == "YES" and self.config["chroot_local_user"] == "YES" )
        self.chRootListEnable.set_active( self.config["chroot_list_enable"] == "YES" )
        self.eRootListEnable.set_text( self.config["chroot_list_file"] )
        self.chGuestEnable.set_active( self.config["guest_enable"] == "YES" )
        self.eGuestEnable.set_text( self.config["guest_username"] )
        if len( self.config["local_root"] ) > 0: self.eLocalRoot.set_text( self.config["local_root"] )
        if len( self.config["user_config_dir"] ) > 0: self.eUserConfigDir.set_text( self.config["user_config_dir"] )
        self.sLocalMaxRate.set_value( float( self.config["local_max_rate"] ) )
        self.eLocalUmask.set_text( self.config["local_umask"] )

        # Anonymous Users
        self.chAllowAnonymousUser.set_active( self.config["anonymous_enable"] == "YES" )
        self.chAllowCreatingNewDirectories.set_active( self.config["anon_mkdir_write_enable"] == "YES" )
        self.chAllowUploadFiles.set_active( self.config["anon_upload_enable"] == "YES" and self.config["write_enable"] == "YES" )
        self.chAskForPassword.set_active( self.config["no_anon_password"] == "YES" )
        self.chAnonymousWorldOnlyEnable.set_active( self.config["anon_world_readable_only"] == "YES" )
        self.chAnonymousUseSSL.set_active( self.config["allow_anon_ssl"] == "YES" )
        self.chAnonymousChOwner.set_active( self.config["chown_uploads"] == "YES" )
        self.eAnonymousChOwner.set_text( self.config["chown_username"]  )
        self.eAnonymousUserName.set_text( self.config["ftp_username"] )
        if len( self.config["anon_root"] ) > 0: self.eAnonymousRootDir.set_text( self.config["anon_root"] )

        self.sAnonymousMaxRate.set_value( float( self.config["anon_max_rate"] ) )
        self.eAnonUmask.set_text( self.config["anon_umask"] )

        self.__enableRootList_toggled( None )
        self.__guestEnable_toggled( None )
        self.__allowLocalUsers( None )
        self.__allowAnonymousUser( None )
        self.__chownUploads_toggled( None )

    def change( self, widget ):
        
        """ Function called when user change some value on the form """
        # Local users
        if widget == self.chUsersChmodEnable: 
            if widget.get_active( ) == True: self.config["chmod_enable"] = "YES"
            else: self.config["chmod_enable"] = "NO"
        if widget == self.chUsersChangeRoot: 
            if widget.get_active( ) == True: self.config["chroot_local_user"] = "YES"
            else: self.config["chroot_local_user"] = "NO"
        if widget == self.chPasswdChRootEnable: 
            if widget.get_active( ) == True: 
                self.config["passwd_chroot_enable"] = "YES"
                self.config["chroot_local_user"] = "YES"
            else: self.config["passwd_chroot_enable"] = "NO"
        if widget == self.eRootListEnable: 
            self.config["chroot_list_file"] = widget.get_text( )
        if widget == self.eGuestEnable: 
            self.config["guest_username"] = widget.get_text( )
        if widget == self.eLocalRoot: 
            self.config["local_root"] = widget.get_text( )
        if widget == self.eUserConfigDir: 
            self.config["user_config_dir"] = widget.get_text( )
        if widget == self.sLocalMaxRate: 
            self.config["local_max_rate"] = `int( widget.get_value( ) )`
        if widget == self.eLocalUmask: # TODO chekck correctness of octal or decimal string
            self.config["local_umask"] = widget.get_text( )

        # Anonymous User
        if widget == self.chAllowCreatingNewDirectories: 
            if widget.get_active( ) == True: self.config["anon_mkdir_write_enable"] = "YES"
            else: self.config["anon_mkdir_write_enable"] = "NO"
        if widget == self.chAllowUploadFiles: 
            if widget.get_active( ) == True: 
		self.config["anon_upload_enable"] = "YES"
		self.config["write_enable"] = "YES"
            else: self.config["anon_upload_enable"] = "NO"
        if widget == self.chAskForPassword: 
            if widget.get_active( ) == True: self.config["no_anon_password"] = "YES"
            else: self.config["no_anon_password"] = "NO"
        if widget == self.chAnonymousWorldOnlyEnable: 
            if widget.get_active( ) == True: self.config["anon_world_readable_only"] = "YES"
            else: self.config["anon_world_readable_only"] = "NO"
        if widget == self.chAnonymousUseSSL: 
            if widget.get_active( ) == True: self.config["allow_anon_ssl"] = "YES"
            else: self.config["allow_anon_ssl"] = "NO"
        if widget == self.eAnonymousChOwner: 
            self.config["chown_username"] = widget.get_text( )
        if widget == self.eAnonymousUserName: 
            self.config["ftp_username"] = widget.get_text( )
        if widget == self.eAnonymousRootDir: 
            self.config["anon_root"] = widget.get_text( )
        if widget == self.sAnonymousMaxRate: 
            self.config["anon_max_rate"] = `int( widget.get_value( ) )`
        if widget == self.eAnonUmask:           # TODO chekck correctness of octal or decimal string
            self.config["anon_umask"] = widget.get_text( )

        # Change
        if widget == self.bRootListEnable:  
            choice = _sys.OSUtils.openFile( )
            if choice: self.eRootListEnable.set_text( choice )
        elif widget == self.bLocalRoot or widget == self.bUserConfigDir or widget == self.bAnonymousRootDir: 
            choice = _sys.OSUtils.openDir( )
        if   widget == self.bLocalRoot and choice:        self.eLocalRoot.set_text( choice )
        elif widget == self.bUserConfigDir and choice:    self.eUserConfigDir.set_text( choice )
        elif widget == self.bAnonymousRootDir and choice: self.eAnonymousRootDir.set_text( choice )


class DirectoryOptions( renderMainWindow ):

    """
        Class that describes functions for render "Directory Options" window
    """

    def __init__( self, mainBox, config, appbar ): 
        """ Constructor that render all widgets  """

        self.startFlag = True

        renderMainWindow.__init__( self, mainBox, config, appbar )
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"directoryH.png", 'Directory Options', 'The following is a list of directives which affect directories' )
        # ------------------------------------------------------------------------------------- #


        self.directoryBox = self.renderVBox( self.mainBox, [5, 0, 0, 0] )

        # [dirlist_enable]
        self.chAllowViewDirectories = self.renderCheckButton( self.directoryBox, 'Allow users to view directory lists' )
        futils.makeConnect( self.chAllowViewDirectories, self.generalFunctions )

        # [use_localtime]
        self.chLocalTime = self.renderCheckButton( self.directoryBox, 'Use localtime instead of GMT' )
        futils.makeConnect( self.chLocalTime, self.generalFunctions )

        # [force_fot_files]
        self.chForceDotFiles = self.renderCheckButton( self.directoryBox, 'List files beginning with a dot (except of "." and ".." files)' )
        futils.makeConnect( self.chForceDotFiles, self.generalFunctions ) 

        # [hide_ids]
        self.chHideIDS = self.renderCheckButton( self.directoryBox, "Show 'ftp' as the user and group instead of real user (group) of each file" )
        futils.makeConnect( self.chHideIDS, self.generalFunctions ) 

        # [text_userdb_names]
        self.chTextUserDBNames = self.renderCheckButton( self.directoryBox, 'Enable using text names for UID and GID (May slow performance)' )
        futils.makeConnect( self.chTextUserDBNames, self.generalFunctions )

        # horisontal separator
        self.renderHBox( self.directoryBox, [5, 5, 0, 0] )

        # frame Directory messages 
        [frame, box] = self.renderFrame( 'Directory mesages' )
        self.directoryBox.pack_start( frame, False, True, 0 )

        # [dirmessage_enable]
        box1 = self.renderHBox( box, [0, 0, 0, 10] )
        self.chMessagedisplay = self.renderCheckButton( box1, 'Enable display messages from files with name:' )
        futils.makeConnect( self.chMessagedisplay, self.generalFunctions )
        # [message_file]
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eMessageFile = self.renderEntry( box1, 30 )
        futils.makeConnect( self.eMessageFile, self.generalFunctions )

        # Entry with box to define anon root directory
        self.renderHBox( self.directoryBox, [5, 5, 0, 0] )
        box = self.renderHBox( self.directoryBox, [0, 0, 0, 0] )

        # frame Directory messages 
        [frame, box] = self.renderFrame( 'File access options' )
        self.directoryBox.pack_start( frame, False, True, 0 )

        # [deny_file]
        box1 = self.renderHBox( box, [5, 0, 0, 10] )
        label2 = self.renderLabel( box1, 'Deny access to all files match the regular expression specified below:', line_wrap_mode=gtk.WRAP_NONE ) 
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eDenyFile = self.renderEntry( box1, 30 )
        futils.makeConnect( self.eDenyFile, self.generalFunctions )

        # [hide_file]
        box1 = self.renderHBox( box, [0, 0, 0, 10] )
        label3 = self.renderLabel( box1, 'Hide all files that match the regular expression specified below:', line_wrap_mode=gtk.WRAP_NONE )
        box1 = self.renderHBox( box, [0, 10, 10, 10] )
        self.eHideFile = self.renderEntry( box1, 30 )
        futils.makeConnect( self.eHideFile, self.generalFunctions )

    def add_mouse_hints( self ):

        self.mouseHints = {
             self.chAllowViewDirectories    : 'When enabled, users are allowed to view directory lists.',
             self.chLocalTime               : 'When enabled, directory listings reveal the local time for the computer instead of GMT',
             self.chForceDotFiles           : 'When enabled, files beginning with a dot (.) are listed in directory listings, with the exception of the . and .. files.',
             self.chHideIDS                 : 'When enabled, all directory listings show ftp as the user and group for each file.',
             self.chTextUserDBNames         : 'By default, numeric IDs are shown in the user and group fields of directory listings. You can get textual names by enabling this parameter.'
                                              ' \nIt is off for performance reasons.',
             self.chMessagedisplay          : 'When enabled, a message is displayed whenever a user enters a directory with a message file specified below as "Message files:"',
             self.eMessageFile              : 'Specifies the name of the message file:',
             self.eDenyFile                 : 'This option can be used to set a pattern for filenames (and directory names etc.) which should not be accessible in any way.',
             self.eHideFile                 : 'This option can be used to set a pattern for filenames (and directory names etc.) which should be hidden from directory listings.'
        }

    def fill( self ):

        """ Function to fill widgets with values from configuration  """
        self.chAllowViewDirectories.set_active( self.config["dirlist_enable"] == "YES" )
        self.chLocalTime.set_active( self.config["use_localtime"] == "YES" )
        self.chForceDotFiles.set_active( self.config["force_dot_files"] == "YES" )
        self.chHideIDS.set_active( self.config["hide_ids"] == "YES" )
        self.chTextUserDBNames.set_active( self.config["text_userdb_names"] == "YES" )
        self.chMessagedisplay.set_active( self.config["dirmessage_enable"] == "YES" )
        self.eMessageFile.set_text( self.config["message_file"] )
        self.eDenyFile.set_text( self.config["deny_file"][ 1:-1] )
        self.eHideFile.set_text( self.config["hide_file"][ 1:-1] )

    def change( self, widget ):

        """ Function called when user change some value on the form """
        if   widget == self.chAllowViewDirectories: 
            if widget.get_active( ) == True: self.config["dirlist_enable"] = "YES"
            else: self.config["dirlist_enable"] = "NO"
        elif widget == self.chLocalTime: 
            if widget.get_active( ) == True: self.config["use_localtime"] = "YES"
            else: self.config["use_localtime"] = "NO"
        elif widget == self.chForceDotFiles: 
            if widget.get_active( ) == True: self.config["force_dot_files"] = "YES"
            else: self.config["force_dot_files"] = "NO"
        elif widget == self.chHideIDS: 
            if widget.get_active( ) == True: self.config["hide_ids"] = "YES"
            else: self.config["hide_ids"] = "NO"
        elif widget == self.chTextUserDBNames: 
            if widget.get_active( ) == True: self.config["text_userdb_names"] = "YES"
            else: self.config["text_userdb_names"] = "NO"
        elif widget == self.chMessagedisplay: 
            if widget.get_active( ) == True: self.config["dirmessage_enable"] = "YES"
            else: self.config["dirmessage_enable"] = "NO"
        elif widget == self.eMessageFile: 
            self.config["message_file"] = widget.get_text( )
        elif widget == self.eDenyFile: 
            self.config["deny_file"] = '{' + widget.get_text( ) + '}'
        elif widget == self.eHideFile: 
            self.config["hide_file"] = '{' + widget.get_text( ) + '}'
        
class Logging( renderMainWindow ):

    """
        Class that describes functions for render "Logging" window
    """

    def __init__( self, mainBox, config, appbar): 
        """ Constructor that render all widgets  """

        self.startFlag = True

        renderMainWindow.__init__( self, mainBox, config, appbar )
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"loggingH.png", 'Logging', 
                'The following is a list of directives which affect vsftpd\'s logging behavior.' )
        # ------------------------------------------------------------------------------------- #


        # Box for rendering system box
        self.logBox = self.renderVBox( self.mainBox, [5, 0, 0, 0] )

        # [dual_log_enable]
        self.chAllowDualLog = self.renderCheckButton( self.logBox, 'Enable dual looging', active=True )
        futils.makeConnect( self.chAllowDualLog, self.generalFunctions )

        # [log_ftp_protocol]
        self.chLogFTPProtocol = self.renderCheckButton( self.logBox, 'Log all FTP commands and respones (useful for debugging)' )
        futils.makeConnect( self.chLogFTPProtocol, self.generalFunctions )

        # [syslog_enable]
        self.chSystemLog = self.renderCheckButton( self.logBox, 'Sent all standard log messages to system logger' )
        futils.makeConnect( self.chSystemLog, self.generalFunctions )

        # [xferlog_enable]
        self.chXFerlogEnable = self.renderCheckButton( self.logBox, 'Log connections and file transfer information' )
        futils.makeConnect( self.chXFerlogEnable, self.generalFunctions )

        # [xferlog_std_format]
        self.chXFerlogStandardFormat = self.renderCheckButton( self.logBox, 'Use standard format for wu-compatible log file', active=True )
        futils.makeConnect( self.chXFerlogStandardFormat, self.generalFunctions )

        # Separator
        self.renderHSeparator( self.logBox, [10, 10, 0, 0], packing=[False,False] )
               
        # [vsftpd_log_file]
        self.lStandardLogFile = self.renderLabel( self.logBox, 'Specify the standard log file:' )
        box1 = self.renderHBox( self.logBox, [0, 10, 10, 10] )
        self.eStandardLogFile = self.renderEntry( box1, 0 )
        futils.makeConnect( self.eStandardLogFile, self.generalFunctions )
        self.bStandardLogFile = self.renderButton( box1, label='Change...', callbacks={"pressed": self.change} )

        # [xferlog_file]
        self.lStandardXFerLogFile = self.renderLabel( self.logBox, 'Specify the wu-ftpd-compatible file:' )
        box1 = self.renderHBox( self.logBox, [0, 10, 10, 10] )
        self.eStandardXFerLogFile = self.renderEntry( box1, 0 )
        futils.makeConnect( self.eStandardXFerLogFile, self.generalFunctions )
        self.bStandardXFerLogFile = self.renderButton( box1, label='Change...', callbacks={"pressed": self.change} )

        self.logBox.show( )

    def add_mouse_hints( self ):

        self.mouseHints = {
             self.chAllowDualLog            : 'When enabled, vsftpd writes two files simultaneously: wu-ftpd compatible log and standard file (both specified below).',
             self.chLogFTPProtocol          : 'When enabled (without wu-compatible log file), all FTP commands and responses are logged. (Useful for debugging).',
             self.chSystemLog               : 'When enabled, all logging normally written to the standard vsftpd log.',
             self.chXFerlogEnable           : 'When enabled, vsftpd logs connections and file transfer information are logged to the standard log and connections to wu-ftpd compatible log.',
             self.chXFerlogStandardFormat   : 'When enabled, only a wu-ftpd-compatible file transfer log is written to the log. This file only logs file transfers.',
             self.eStandardLogFile          : 'Specifies the vsftpd log file. To use this file, beware that system log is disabled...',
             self.eStandardXFerLogFile      : 'Specifies the wu-ftpd-compatible log file.'
        }

    def fill( self ):

        """ Function to fill widgets with values from configuration  """
        self.chAllowDualLog.set_active( self.config["dual_log_enable"] == "YES" and self.config["xferlog_enable"] == "YES" )
        self.chLogFTPProtocol.set_active( self.config["log_ftp_protocol"] == "YES" and self.config["xferlog_enable"] == "YES" and self.config["xferlog_std_format"] == "NO" )
        self.chSystemLog.set_active( self.config["syslog_enable"] == "YES" and self.config["xferlog_enable"] == "YES" )
        self.chXFerlogEnable.set_active( self.config["xferlog_enable"] == "YES" )
        self.chXFerlogStandardFormat.set_active( self.config["xferlog_std_format"] == "YES" and self.config["xferlog_enable"] == "YES" )
        self.eStandardLogFile.set_text( self.config["vsftpd_log_file"] )
        self.eStandardXFerLogFile.set_text( self.config["xferlog_file"] )

    def change( self, widget ):

        """ Function called when user change some value on the form """
        if widget == self.chAllowDualLog: 
            if widget.get_active( ) == True: 
                self.config["dual_log_enable"] = "YES"
                self.config["xferlog_enable"] = "YES"
            else: self.config["dual_log_enable"] = "NO"
        if widget == self.chLogFTPProtocol: 
            if widget.get_active( ) == True: 
                self.config["log_ftp_protocol"] = "YES"
                self.config["xferlog_enable"] = "YES"
                self.config["xferlog_std_format"] = "NO"
            else: self.config["log_ftp_protocol"] = "NO"
        if widget == self.chSystemLog: 
            if widget.get_active( ) == True: 
                self.config["syslog_enable"] = "YES"
                self.config["xferlog_enable"] = "YES"
            else: self.config["syslog_enable"] = "NO"
        if widget == self.chXFerlogEnable: 
            if widget.get_active( ) == True: self.config["xferlog_enable"] = "YES"
            else: self.config["xferlog_enable"] = "NO"
        if widget == self.chXFerlogStandardFormat: 
            if widget.get_active( ) == True: 
                self.config["xferlog_std_format"] = "YES"
                self.config["xferlog_enable"] = "YES"
            else: self.config["xferlog_std_format"] = "NO"
        if widget == self.eStandardLogFile: 
            self.config["vsftpd_log_file"] = widget.get_text( )
        if widget == self.eStandardXFerLogFile: 
            self.config["xferlog_file"] = widget.get_text( )

        if widget in [ self.bStandardLogFile, self.bStandardXFerLogFile ]:
            choice = _sys.OSUtils.openFile( )
        if   widget == self.bStandardLogFile and choice:        self.eStandardLogFile.set_text( choice )
        elif widget == self.bStandardXFerLogFile and choice:    self.eStandardXFerLogFile.set_text( choice )

        self.fill( )

class NetworkOptions( renderMainWindow ):

    """
        Class that describes functions for render "Network Options" window
    """

    def __init__( self, mainBox, config, appbar ): 
        """ Constructor that render all widgets  """

        self.startFlag = True

        renderMainWindow.__init__( self, mainBox, config, appbar )
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"networkH.png", 'Network Options', 
                'The following is a list of directives which affect how vsftpd interacts whith the network' )
        # ---------------------------------------------------------------------------------------- #


        self.networkBox = self.renderVBox( self.mainBox, [5, 0, 0, 0] )
        self.networkNotebook = self.renderNoteBook( self.mainBox )


        # General
        # ------------------------------------------------------------------------------------- #

        # [connect_from_port_20]
        self.chConnectFromPort20 = self.renderCheckButton( self.networkBox, 'Run vsftpd with enough privileges to open port 20 on the server '
                                                                              'during active mode data transfers', active=True )
        futils.makeConnect( self.chConnectFromPort20, self.generalFunctions )

        label = self.renderLabel( self.networkBox, '<i>Disabling this option allows vsftpd to run with less privileges, but may be incompatible '
                                                     'with some FTP clients</i>', line_wrap_mode=gtk.WRAP_NONE )


        # horizontal separator
        self.renderHBox( self.networkBox, [5, 5, 0, 0] )

        box = self.renderHBox( self.networkBox, [5, 0, 0, 0] )

        # [data_connection_timeout]
        self.lDataConTimeOut = self.renderLabel( None, 'Maximum amount of time to stall the data transfer:   ' ) 
        self.sDataConTimeOut = self.renderSpinButton( None, [300.0, 0.0, 3600.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sDataConTimeOut, self.generalFunctions )
        self.lDataConTimeOut2 = self.renderLabel( None, '   seconds' ) 

        # [idle_session_timeout]
        self.lIdleSession = self.renderLabel( None, 'Maximum amount of time between commands from client:   ' ) 
        self.sIdleSession = self.renderSpinButton( None, [300.0, 0.0, 3600.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sIdleSession, self.generalFunctions )
        self.lIdleSession2 = self.renderLabel( None, '   seconds' ) 

        # [liten_port]
        self.lListenPort = self.renderLabel( None, 'Port on wich vsftpd listens for network connection:   ' ) 
        self.sListenPort = self.renderSpinButton( None, [21.0, 0.0, 65535.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sListenPort, self.generalFunctions  )

        # [max_clients]
        self.lMaxClients = self.renderLabel( None, 'Maximum number of simultaneous clients allowed to connect to the server:   ' ) 
        self.sMaxClients = self.renderSpinButton( None, [21.0, 0.0, 9999.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sMaxClients, self.generalFunctions )

        # [max_per_ip]
        self.lMaxPerIP = self.renderLabel( None, 'Maximum of clients allowed to connect from the same source IP address:   ' ) 
        self.sMaxPerIP = self.renderSpinButton( None, [0.0, 0.0, 999.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sMaxPerIP, self.generalFunctions )

        tableModel = [ [ self.lDataConTimeOut, self.sDataConTimeOut, self.lDataConTimeOut2 ],
                       [ self.lIdleSession, self.sIdleSession, self.lIdleSession2 ],
                       [ self.lListenPort, self.sListenPort, None ],
                       [ self.lMaxClients, self.sMaxClients, None ],
                       [ self.lMaxPerIP, self.sMaxPerIP, None ] ]

        futils.renderTable( box, tableModel )

        # Separator
        self.renderHSeparator( self.networkBox, [10, 10, 0, 0], packing=[False,False] )

        # Active connection
        # ------------------------------------------------------------------------------------- #

        """ 
        I did to boxes, first anonymousBox, where is checkbox to allow other options
        and second, where I take other options. It is simple to set sensitivity to all options
        in one command 
        """
        # Box for rendering system box
        self.activeBox = self.renderNBPage( self.networkNotebook, 'Active connection', align=[10,10,10,10] )

        self.renderLabel( self.activeBox, "<i>Active connection: Data is sent through same port as commands</i>" )
        
        # horizontal separator
        self.renderHBox( self.activeBox, [5, 5, 0, 0] )

        # [port_enable]
        self.chAllowActive = self.renderCheckButton( self.activeBox, 'Enable active connections' )
        futils.makeConnect( self.chAllowActive, [self.__allowActiveConnection_toggled] + self.generalFunctions[1:] )
        
        # horizontal separator
        self.renderHBox( self.activeBox, [5, 5, 0, 0] )
        box = self.renderHBox( self.activeBox, [0, 0, 0, 0] )

        # [connect_timeout]
        self.lAConnectionTimeOut = self.renderLabel( None, 'Maximum amount of time a client has to respond to a data connection:   ' ) 
        self.sAConnectionTimeOut = self.renderSpinButton( None, [300.0, 0.0, 3600.0, 1.0, 100.0, 0.0], 0, 0) 
        futils.makeConnect( self.sAConnectionTimeOut, self.generalFunctions )
        self.lAConnectionTimeOut2 = self.renderLabel( None, '   seconds' ) 

        # [ftp_data_port]
        self.lADataPort = self.renderLabel( None, 'Port used for active data connections:   ' )
        self.sADataPort = self.renderSpinButton( None, [20.0, 0.0, 65535.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sADataPort, self.generalFunctions )


        tableModel = [ [ self.lAConnectionTimeOut, self.sAConnectionTimeOut, self.lAConnectionTimeOut2 ],
                       [ self.lADataPort, self.sADataPort, None ] ]

        futils.renderTable( box, tableModel )

        # ------------------------------------------------------------------------------------- #
        # Passive connection

        """ 
        I did to boxes, first anonymousBox, where is checkbox to allow other options
        and second, where I take other options. It is simple to set sensitivity to al options
        in one command 
        """
        # Box for rendering system box
        self.passiveBox = self.renderNBPage( self.networkNotebook, 'Passive connections', align=[10,10,10,10] )

        self.renderLabel( self.passiveBox, '<i>Passive connection: Data are sending throw different ports as commands</i>', line_wrap_mode=gtk.WRAP_NONE )
        
        # horizontal separator
        self.renderHBox( self.passiveBox, [5, 5, 0, 0] )

        # [pasv_enable]
        self.chAllowPassive = self.renderCheckButton( self.passiveBox, 'Enable passive connections' )
        futils.makeConnect( self.chAllowPassive, [self.__allowPassiveConnection_toggled] + self.generalFunctions[1:] )
        
        # horizontal separator
        self.renderHBox( self.passiveBox, [5, 5, 0, 0] )
        box = self.renderHBox( self.passiveBox, [0, 0, 0, 0] )

        # [accept_timeout]
        self.lPAcceptTimeOut = self.renderLabel( None, 'Maximum amount of time for a client to establish a connection:   ' ) 
        self.sPAcceptTimeOut = self.renderSpinButton( None, [300.0, 0.0, 3600.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sPAcceptTimeOut, self.generalFunctions )
        self.lPAcceptTimeOut2 = self.renderLabel( None, '   seconds' ) 

        # [pasv_max_port] [pasv_min_port]
        self.lPPorts = self.renderLabel( None, 'Range of ports to bind by passive data transfer:   ' )
        self.sPMinPort = self.renderSpinButton( None, [1024.0, 1024.0, 65535.0, 1.0, 100.0, 0.0], 0, 0)
        futils.makeConnect( self.sPMinPort, self.generalFunctions )
        self.lPPorts2 = self.renderLabel( None, ' - ' ) 
        self.sPMaxPort = self.renderSpinButton( None, [65535.0, 1024.0, 65535.0, 1.0, 100.0, 0.0], 0, 0 )
        futils.makeConnect( self.sPMaxPort, self.generalFunctions )

        tableModel = [ [ self.lPAcceptTimeOut, self.sPAcceptTimeOut, None, self.lPAcceptTimeOut2 ],
                       [ self.lPPorts, self.sPMinPort, self.lPPorts2, self.sPMaxPort ] ]

        futils.renderTable( box, tableModel )

        # horizontal separator
        self.renderHBox( self.passiveBox, [5, 5, 0, 0] )

        # [pasv_promiscuous]
        self.chPPasvPromiscuous = self.renderCheckButton( self.passiveBox, 'Check to make sure, that data connections are originating from the same IP' )
        futils.makeConnect( self.chPPasvPromiscuous, self.generalFunctions )

    def __allowActiveConnection_toggled( self, widget ):
        """Called when checkbox on allowing active connections get toggled"""
        self.lAConnectionTimeOut.set_sensitive ( self.chAllowActive.get_active( ) )
        self.lAConnectionTimeOut2.set_sensitive( self.chAllowActive.get_active( ) )
        self.sAConnectionTimeOut.set_sensitive ( self.chAllowActive.get_active( ) )
        self.lADataPort.set_sensitive( self.chAllowActive.get_active( ) )
        self.sADataPort.set_sensitive ( self.chAllowActive.get_active( ) )

        # Set Config
        if widget.get_active( ) == True: self.config["port_enable"] = "YES"
        else: self.config["port_enable"] = "NO"

    def __allowPassiveConnection_toggled( self, widget ):
        """Called when checkbox on allowing passive connections get toggled"""
        self.lPAcceptTimeOut.set_sensitive ( self.chAllowPassive.get_active( ) )
        self.lPAcceptTimeOut2.set_sensitive( self.chAllowPassive.get_active( ) )
        self.sPAcceptTimeOut.set_sensitive( self.chAllowPassive.get_active( ) )
        self.lPPorts.set_sensitive ( self.chAllowPassive.get_active( ) )
        self.lPPorts2.set_sensitive( self.chAllowPassive.get_active( ) )
        self.sPMinPort.set_sensitive( self.chAllowPassive.get_active( ) )
        self.sPMaxPort.set_sensitive( self.chAllowPassive.get_active( ) )
        self.chPPasvPromiscuous.set_sensitive( self.chAllowPassive.get_active( ) )

        # Set Config
        if widget.get_active( ) == True: self.config["pasv_enable"] = "YES"
        else: self.config["pasv_enable"] = "NO"

    def add_mouse_hints( self ):

        self.mouseHints = {
             self.chConnectFromPort20   : 'When enabled, vsftpd runs with enough privileges to open port 20 on the server during active mode data transfers.',
             self.sDataConTimeOut       : 'Specifies maximum amount of time data transfers are allowed to stall, in seconds.',
             self.sIdleSession          : 'Specifies the maximum amount of time between commands from a remote client.',
             self.sListenPort           : 'Spcifies the port on which vsftpd listens for network connections.',
             self.sMaxClients           : 'Specifies the maximum number of simultaneous clients allowed to connect to the server when it is running in standalone mode.',
             self.sMaxPerIP             : 'Specifies the maximum of clients allowed to connected from the same source IP address',
             self.chAllowActive         : 'When enabled, active mode connects are allowed.',
             self.sAConnectionTimeOut   : 'Specifies maximum amount of time a client using active mode has to respond to a data connection, in seconds.',
             self.sADataPort            : 'Specifies the port used for active data connections.',
             self.chAllowPassive        : 'When enabled, passive mode connects are allowed.',
             self.sPAcceptTimeOut       : 'Specifies the amount of time for a client using passive mode to establish a connection.',
             self.sPMinPort             : 'Specifies the lowest possible port sent to the FTP clients for passive mode connections.',
             self.sPMaxPort             : 'Specifies the highest possible port sent to the FTP clients for passive mode connections.',
             self.chPPasvPromiscuous    : 'Only enable if you know what you are doing! The only legitimate use for this is in some form of secure tunnelling scheme, or perhaps to facilitate FXP support.'
        }


    def fill( self ):

        """ Function to fill widgets with values from configuration  """
        # General
        self.chConnectFromPort20.set_active( self.config["connect_from_port_20"] == "YES" )
        self.sDataConTimeOut.set_value( float( self.config["data_connection_timeout"] ) )
        self.sIdleSession.set_value( float( self.config["idle_session_timeout"] ) )
        self.sListenPort.set_value( float( self.config["listen_port"] ) )
        self.sMaxClients.set_value( float( self.config["max_clients"] ) )
        self.sMaxPerIP.set_value( float( self.config["max_per_ip"] ) )

        # Active
        self.chAllowActive.set_active( self.config["port_enable"] == "YES" )
        self.sAConnectionTimeOut.set_value( float( self.config["connect_timeout"] ) )
        self.sADataPort.set_value( float( self.config["ftp_data_port"] ) )

        # Passive
        self.chAllowPassive.set_active( self.config["pasv_enable"] == "YES" )
        self.sPAcceptTimeOut.set_value( float( self.config["accept_timeout"] ) )
        self.sPMinPort.set_value( float( self.config["pasv_min_port"] ) )
        self.sPMaxPort.set_value( float( self.config["pasv_max_port"] ) )
        self.chPPasvPromiscuous.set_active( self.config["pasv_promiscuous"] == "YES" )

    def change( self, widget ):

        """ Function called when user change some value on the form """
        if widget == self.chConnectFromPort20: 
            if widget.get_active( ) == True: self.config["connect_from_port_20"] = "YES"
            else: self.config["connect_from_port_20"] = "NO"
        elif widget == self.sDataConTimeOut: 
            self.config["data_connection_timeout"] = `int( widget.get_value( ) )`
        elif widget == self.sIdleSession: 
            self.config["idle_session_timeout"] = `int ( widget.get_value( ) )`
        elif widget == self.sListenPort: 
            self.config["listen_port"] = `int( widget.get_value( ) )`
        elif widget == self.sMaxClients: 
            self.config["max_clients"] = `int( widget.get_value( ) )`
        elif widget == self.sMaxPerIP: 
            self.config["max_per_ip"] = `int( widget.get_value( ) )`

        # Active
        elif widget == self.sAConnectionTimeOut: 
            self.config["connect_timeout"] = `int( widget.get_value( ) )`
        elif widget == self.sADataPort: 
            self.config["ftp_data_port"] = `int( widget.get_value( ) )`

        # Passive
        elif widget == self.sPAcceptTimeOut: 
            self.config["accept_timeout"] = `int( widget.get_value( ) )`
        elif widget == self.sPMinPort: 
            if int( widget.get_value( ) ) == 1024: 
                self.config["pasv_min_port"] = `0`
            else:
                self.config["pasv_min_port"] = `int( widget.get_value( ) )`
        elif widget == self.sPMaxPort: 
            if int( widget.get_value( ) ) == 65535: 
                self.config["pasv_max_port"] = `0`
            else:
                self.config["pasv_max_port"] = `int( widget.get_value( ) )`
        elif widget == self.chPPasvPromiscuous: 
            if widget.get_active( ) == True: self.config["pasv_promiscuous"] = "YES"
            else: self.config["pasv_promiscuous"] = "NO"


class TransferLog( renderMainWindow ):

    """
        Class that describes functions for render "Transfer Log" window
    """

    def __init__( self, mainBox, config, appbar ): 

        """ Constructor that render all widgets  """

        self.startFlag = True

        renderMainWindow.__init__( self, mainBox, config, appbar )
        self.startFlag = False

    def build( self ):

        # render main window from click on the left side
        futils.renderMainLabel( self.mainBox, self.ico_path+"logH.png", 'Transfer log', 'Read only xferlog in graphical format' )
        # ---------------------------------------------------------------------------------------- #


        # generating box
        self.cIPBox = self.renderHBox( self.mainBox, [0, 0, 0, 0] )

        # generating calendar
        self.calendar = gtk.Calendar( )
        self.calendar.connect("month_changed", self.__calendar_toggled)
        self.calendar.connect("day_selected", self.__calendar_toggled)
        self.calendar.connect("day_selected_double_click", self.__calendar_toggled)
        self.calendar.connect("prev_month", self.__calendar_update)
        self.calendar.connect("next_month", self.__calendar_update)
        self.calendar.connect("prev_year", self.__calendar_update)
        self.calendar.connect("next_year", self.__calendar_update)

        self.cIPBox.pack_start( self.calendar, False, False, 0 )
        self.calendar.show( )

        self.renderVSeparator( self.cIPBox, [0, 0, 5, 5], packing=[False,False] )

        self.IPscWindow = self.renderScrolledWindow( self.cIPBox )
        self.IPscWindow.set_border_width( 0 )

        self.renderHSeparator( self.mainBox, [5, 5, 0, 0], packing=[False,False] )
        box1 = self.renderHBox( self.mainBox, [0, 0, 0, 0] )
        self.bReloadLogs = self.renderButton( box1, label="  Reload log  ", callbacks={"pressed": self.__logs} )
        self.renderVBox( box1, [0,0,5,5,], packing=[False, False] )
        align, self.progressBar = self.renderProgressBar( box1, align=[2,2,2,2] )
        self.renderHSeparator( self.mainBox, [5, 5, 0, 0], packing=[False,False] )

        ( alignment, self.logBox) = self.renderVBox( None, [0, 0, 0, 0] )
        self.scWindow = self.renderScrolledWindow( self.mainBox, alignment )
        self.scWindow.set_border_width( 0 )
        

    def __calendar_toggled( self, widget):
        """When changed day in calendar"""
        year, month, day = self.calendar.get_date()
        date = `day`+'.'+self.log.get_number_month( month+1 )+'.'+`year`
        self.__IPListStore.clear( )
        if self.log.dict != None:
            if date in self.log.dict:
                for ip in self.log.dict[ date ]:
                    self.__IPListStore.append( [ip] )
        self.__IPList.get_selection( ).select_path( 0 )

    def __calendar_update( self, widget):
        """When changed year or month in calendar"""

        self.calendar.clear_marks( )
        yearc, monthc, dayc = self.calendar.get_date()
        if self.log.dict == None: return
        for date in self.log.dict:
            day, month, year = self.log.parse_date( date )
            if ( month, year ) == ( monthc+1, yearc ):
                self.calendar.mark_day( day )
        self.__calendar_toggled( None )

    def __iplist_changed( self, widget ):
        """When changed focused line in ipList """

        #path="ico/"
        path="/usr/share/pixmaps/system-config-vsftpd/ico/"
        __ico_download = gtk.gdk.pixbuf_new_from_file(path+"download.png")
        __ico_upload = gtk.gdk.pixbuf_new_from_file(path+"upload.png")

        year, month, day = self.calendar.get_date()
        date = `day`+'.'+self.log.get_number_month( month+1 )+'.'+`year`
        self.__fileListStore.clear( )
        ( model, iter ) = widget.get_selected( )
        if iter:
            i = -1
            ip = model.get_value( iter, 0 ) 
            __pLines = self.log.parse( date, ip )
            for __line in __pLines:
                i = i + 1
                # if ? on user identification
                if __line[9][0] == "?" or __line[9][0] == ' ': user = "ftp"
                else: user = __line[9]

                if __line[7][0] == "i": 
                    self.__fileListStore.append( [__line[0],__ico_download,user,`__line[4]`] )
                else: self.__fileListStore.append( [__line[0],__ico_upload,user,`__line[4]`] )

    def updateProgressBar( self, step, dict=None ):

        self.progressBar.set_fraction( float(step)/100 )
        self.progressBar.set_text( `step`+" %" )
        if step == 100:
            self.log.dict = dict
            if self.log.dict == None:
                    self.renderLabel( self.logBox, "<b>Log doesn't exists, try to select one in 'Logging' menu</b>", padding=[20, 10] )
                    return

            if len( self.log.dict.keys() ) == 0:
                    self.renderLabel( self.logBox, "<b>Log is empty</b>", padding=[20, 10] )
                    return

            #: log loaded - create stores
            self.__fileListStore, self.__fileList = futils.create_File_List( self.logBox )
            self.__calendar_update( None )
            self.appbar.set_status( "" )

    def __logs( self, widget=None ):
        
        if widget != None: #: == None: first run when clicked on Transfer menu button
            self.__IPList.get_model().clear()
            self.calendar.clear_marks( )
        for child in self.logBox.get_children(): child.destroy() #: destroy treeview with files preview

        #: get log file
        self.log = logs.Log( self.config )
        file = logs.Log.loadFile( self.config )
        if file == None: #: file does not exist, there's nothing to parse
            self.updateProgressBar( 100, None )
            return
        #: all clear - parse log file
        self.loader = _sys.LogsLoader( file, self )
        self.loader.start( )

    def fill( self ):

        #: first create objects to destroy them in __logs method ;)
        self.__fileListStore, self.__fileList = futils.create_File_List( self.logBox )
        self.__IPListStore, self.__IPList   = futils.create_IP_List( self.IPscWindow )
        self.__logs( )
        
        # to know about rows selecting
        treeSelection = self.__IPList.get_selection( )
        treeSelection.connect( 'changed', self.__iplist_changed )

        self.__calendar_update( None )
        self.appbar.set_status( "" )

    def change( self ):
        pass

    def add_mouse_hints( self ):
        pass
