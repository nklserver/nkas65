#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import GTK and PyGTK libraries
import gtk

# Import stock python libraries
import re
import string
import gettext
_ = gettext.gettext

from shell      import Shell
from sysutils   import Error
from exitDialog import exitDialog
import sysutils

class Configuration:

    """
        Class used for parsing configuration file. Describes functions to save, load coonfiguration or
        restart server.
    """

    def __init__( self, fname, old_config=None ):
        """
        Constructor of object Configuration.
        Make default configuration, fill structures with configuration from file and save new configuration.
        """

        # Default values
        """ Default options, please DO NOT CHANGE ! """
        self.default = { # Daemon options
                        "listen"                    : "NO",
                        "listen_ipv6"               : "NO",
                        "background"                : "NO", #TODO
                        "session_support"           : "NO", #TODO

                        # ---Log In Options and Access Controls---------------------
                        "banned_email_file"         : "/etc/vsftpd.baned_emails", 
                        "banner_file"               : "",
                        "cmds_allowed"              : "", #TODO
                        "deny_email_enable"         : "NO",
                        "ftpd_banner"               : "",
                        "pam_service_name"          : "ftp", 
                        "tcp_wrappers"              : "NO",
                        "userlist_deny"             : "YES",
                        "userlist_enable"           : "NO",
                        "userlist_file"             : "/etc/vsftpd.user_list", 
                        "cmds_allowed"              : "", #TODO

                        # ---Anonymous Use Options----------------------------------
                        "anonymous_enable"          : "YES",
                        "anon_mkdir_write_enable"   : "NO",
                        "anon_root"                 : "",
                        "anon_upload_enable"        : "NO",
                        "anon_world_readable_only"  : "YES",
                        "ftp_username"              : "ftp", 
                        "no_anon_password"          : "NO",
                        "anon_umask"                : "077",
                        "allow_anon_ssl"            : "NO", 
                        
                        # ---Local User Options-------------------------------------
                        "local_enable"              : "NO",
                        "chmod_enable"              : "YES",
                        "chroot_list_enable"        : "NO",
                        "chroot_list_file"          : "/etc/vsftpd.chroot_list",
                        "chroot_local_user"         : "NO",
                        "guest_enable"              : "NO",
                        "guest_username"            : "ftp",
                        "local_root"                : "",
                        "passwd_chroot_enable"      : "NO",
                        "user_config_dir"           : "",


                        # ---Directory Options--------------------------------------
                        "dirlist_enable"            : "YES",
                        "dirmessage_enable"         : "NO",
                        "force_dot_files"           : "NO",
                        "hide_ids"                  : "NO",
                        "message_file"              : ".message",
                        "text_userdb_names"         : "NO",
                        "use_localtime"             : "NO",
                        "local_umask"               : "077",
                        "deny_file"                 : "", 
                        "hide_file"                 : "",
                        "secure_chroot_dir"         : "/usr/share/empty",   # TODO - to security ?

                        # ---File Transfer Options----------------------------------
                        "download_enable"           : "YES",
                        "chown_uploads"             : "NO",
                        "chown_username"            : "root",
                        "write_enable"              : "NO",
                        "file_open_mode"            : "0666",

                        # ---Logging Options----------------------------------------
                        "dual_log_enable"           : "NO",
                        "log_ftp_protocol"          : "NO",
                        "syslog_enable"             : "NO",
                        "vsftpd_log_file"           : "/var/log/vsftpd.log",
                        "xferlog_enable"            : "NO",
                        "xferlog_file"              : "/var/log/xferlog",
                        "xferlog_std_format"        : "NO",
                        "no_log_lock"               : "NO", # TODO - deprecated

                        # ---Network Options----------------------------------------
                        "accept_timeout"            : "60",
                        "anon_max_rate"             : "0",
                        "connect_from_port_20"      : "NO",
                        "connect_timeout"           : "60",
                        "data_connection_timeout"   : "300",
                        "ftp_data_port"             : "20",
                        "idle_session_timeout"      : "300",
                        "listen_address"            : "",
                        "listen_address"            : "",
                        "listen_port"               : "21",
                        "local_max_rate"            : "0",
                        "max_clients"               : "0",
                        "max_per_ip"                : "0",
                        "pasv_address"              : "",
                        "pasv_enable"               : "YES",
                        "pasv_max_port"             : "0",
                        "pasv_min_port"             : "0",
                        "pasv_promiscuous"          : "NO",
                        "port_enable"               : "YES",
                        "trans_chunk_size"          : "0",  # TODO - not need to use

                        # ---SSL---------------------------------------------------- #TODO
                        "ssl_enable"                : "NO",
                        "force_local_data_ssl"      : "YES",
                        "force_local_logins_ssl"    : "YES",
                        "ssl_sslv2"                 : "NO",
                        "ssl_sslv3"                 : "NO",
                        "ssl_tlsv1"                 : "YES",
                        "dsa_cert_file"             : "",  
                        "rsa_cert_file"             : "/usr/share/ssl/certs/vsftpd.pem",
                        "ssl_ciphers"               : "DES-CBC3-SHA",

                        # ---Other Options------------------------------------------ #TODO
                        "anon_other_write_enable"   : "NO",
                        "ascii_download_enable"     : "NO",
                        "ascii_upload_enable"       : "NO",
                        "async_abor_enable"         : "NO",
                        "check_shell"               : "YES",
                        "ls_recurse_enable"         : "NO",
                        "one_process_model"         : "NO", # 2.4 kernel only
                        "run_as_launching_user"     : "NO",
                        "secure_email_list_enable"  : "NO",
                        "setproctitle_enable"       : "NO",
                        "tilde_user_enable"         : "NO",
                        "use_sendfile"              : "YES",
                        "virtual_use_local_privs"   : "NO",
                        "email_password_file"       : "/etc/vsftpd.email_passwords",
                        "nopriv_user"               : "nobody",
                        "user_sub_token"            : ""
                        }

        self.shell = Shell( )
        self.loadConfig( fname, old_config )

    def __getitem__( self, item ):
        """ Methode called when variable is getting from object """

        if item in self.new: return self.new[item]
        elif item in self.current: return self.current[item]
        elif item in self.default: return self.default[item]
        else: 
            Error.PErrorConsole( 101, _("Item")+" '"+item+"' "+_("not found") )
            return None

    def __setitem__( self, item, value ):
        """ Methode called when object's variable is changed """

        assert _("Setting variable)")+" %s [%s]" % (item, value )
        self.new[item] = value

    def __restartServer( self ):
        """ Methode for confirming the restart of the server """

        mbox = gtk.MessageDialog( None, gtk.DIALOG_MODAL, gtk.MESSAGE_QUESTION, gtk.BUTTONS_YES_NO, _('New configuration was saved.\nDo you want to restart the server now ?') )
        response = mbox.run( )
        mbox.hide( )
        mbox.destroy( )
        if response == gtk.RESPONSE_YES:
            assert _(" [*] Restarting server...")
            message = self.shell.restartServer( )
            print message

    def loadConfig( self, fname, old_config=None ):
        """ Methode for loading configuration from server's configuration file (/etc/vsftpd/vsftpd.conf) """

	self.pathname = fname

        #self.new = self.default.copy()
        if old_config == None: self.new = {}
        else: self.new = old_config
        self.current = {}

	if self.pathname == False:
	   return False

        #print "File to open: "+self.pathname
        confFile = open( self.pathname, 'r')
        self.lines = confFile.readlines()
        confFile.close( )

        # remove comments and free lines
        try: 

            for line in self.lines:
                if line[0] != "#" and len(line) > 2:
                    line = string.rstrip( line )
                    list = string.split( line, "=" )
                    if string.upper( list[1] ) == "YES" or string.upper( list[1] ) == "NO":
                        self.current[ list[0] ] = string.upper( list[1] )
                    else: 
                        self.current[ list[0] ] = list[1]
                    #else: print " *** [E] Unknown option: %s" % ( list[0] )
        except IndexError:
            sysutils.Error.PErrorMessageBox( 503, _("Configuration file is damaged !") )
            mbox.run( )
            mbox.hide( )
            mbox.destroy( )
            self.new = None
            return False

        assert _(" [L] Loading: "), self.pathname
        #self.new.update( self.current )
        return True

    def saveConfig( self, window ):
        """ Methode for saving configuration to server file (/etc/vsftpd/vsftpd.conf) """

        for variable in self.new.keys( ):
            if variable in self.current:
                if self.new[variable] == self.current[variable]: del self.new[variable]
            elif self.new[variable] == self.default[variable]: del self.new[variable]

        if len( self.new ) == 0: return None #: there's nothing to save

        # variable is in default configuration
        for variable in self.new.keys( ): 
                # remove variable, which is default
            if variable in self.default and ( self.new[variable] == self.default[variable] or self.new[variable] == '{}' ):
                    #del self.new[variable]
                    exp = re.compile( r" *"+variable+"=" )
                    nexp = re.compile( r" *#" )
                    for e, line in enumerate( self.lines ):
                        if exp.search( line ) and not nexp.search( line ): 
                            self.lines[ e ] = "#" + line
                            assert _(" [C] Commenting variable: ") + variable

                # find commented variables and uncommend them, if in new config
            else:
                found = False
                exp = re.compile( "^\s?"+variable+"=" )
                nexp = re.compile( "^\s*#\s*"+variable+"=" )
                assert _(' [F] Finding expression for variable (non default): ') + variable 
                for e, line in enumerate( self.lines ):
                    # it is writed in configuration, check for correct value
                    if exp.search( line ): 
                        # found second one, comment it
                        if found: self.lines[ e ] = "#" + line
                        found = True
                        self.lines[ e ] = line[ string.find( line, variable ) : string.find( line, "=" )+1 ] + self.new[ variable ] + '\n'
                        assert _(" [R] Reseting writed variable")+" (%d) '%s' to %s" % ( e, variable, self.new[ variable ] )
                    elif nexp.search( line ):
                        # found second one, do nothing
                        if found: break
                        self.lines[ e ] = line[ string.find( line, "#" )+1 : string.find( line, "=" )+1 ] + self.new[ variable ] + '\n'
                        assert _(" [R] Reseting commented variable")+" (%d) '%s' to %s" % ( e, variable, self.new[ variable ] )
                        found = True
                if not found:
                   self.lines.append( variable + "=" + self.new[variable] + "\n" )
                   assert " [A] Appending: " + variable 

        #for variable in self.new.keys( ):
        #    print variable, " ", self.new[variable]

        self.default.update( self.current )
        choice = exitDialog( window, self.new, self.default ).run()
        if choice == 3: return self.new
        elif choice == 0 or choice == 1:
            assert _(" [*] Writing to file...")
            confFile = open( self.pathname, "w" )
            confFile.writelines( self.lines )
            confFile.close( )
            if choice == 1: 
                output = self.shell.restartServer()
                print output
        else: return None
