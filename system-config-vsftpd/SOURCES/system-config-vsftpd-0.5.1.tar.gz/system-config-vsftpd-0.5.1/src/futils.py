#!/usr/bin/env python
# -*- coding: UTF8 -*-

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This file is part of system-config-vsftpd
#
# System-config-vsftpd is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# ( at your option ) any later version.
# 
# System-config-vsftpd is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Gnome-todo-manager; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

# Import GTK libraries
import gtk
import gettext
from guiRender import PrimitiveObjects as renderer
_ = gettext.gettext

def renderMainLabel( mainBox, ico, label, text ):
    """Render function for MainLabel showed on top of main window"""

    __renderer = renderer()
    # Label - one picture, two lines of text
    labelBox = __renderer.renderHBox( mainBox )
    alignment = __renderer.renderAlignment( labelBox, 0, 5, 0, 10, packing=[False, False] )
    image = gtk.Image( )
    image.set_from_pixbuf( gtk.gdk.pixbuf_new_from_file( ico ) )
    image.show( )
    alignment.add( image )

    label = __renderer.renderLabel( labelBox, ' <b>'+label+'</b>\n '+text, line_wrap_mode=gtk.WRAP_NONE )

    # horizontal separator
    __renderer.renderHSeparator( mainBox, align=[5, 10, 0, 0], packing=[False, True] )

def renderTable( box, tableModel ):
    """Function to render table from tableModel as parameter"""

    # count rows and cols
    rowsCount = len ( tableModel )
    colsCount = 0
    for list in tableModel:
        if len ( list ) > colsCount: colsCount = len( list )

    table = gtk.Table( rowsCount, colsCount, False )
    rowP = -1
    for list in tableModel:
        rowP = rowP + 1
        lenList = len( list )
        colP = -1
        for obj in list:
            colP = colP + 1
            der = colsCount - lenList
            if colP == 0: 
                if obj: table.attach( obj, colP, colP+1+der, rowP, rowP+1, gtk.FILL )
            else: 
                if obj: table.attach( obj, colP+der, colP+1+der, rowP, rowP+1, gtk.FILL )

    if box != None: box.pack_start( table, False, False, 0 )
    table.show( )

def makeConnect( widget, functions ):
    """Function to connect events to widgets"""

    if type( widget ) == gtk.Entry:
        if functions[0] != None: widget.connect( 'changed', functions[0] )
        if functions[1] != None: widget.connect( 'enter-notify-event', functions[1] )
        if functions[2] != None: widget.connect( 'leave-notify-event', functions[2] )

    elif type( widget ) == gtk.SpinButton:
        if functions[0] != None: widget.connect( 'value_changed', functions[0] )
        if functions[1] != None: widget.connect( 'enter-notify-event', functions[1] )
        if functions[2] != None: widget.connect( 'leave-notify-event', functions[2] )

    else:
        if functions[0] != None: widget.connect( 'toggled', functions[0] )
        if functions[1] != None: widget.connect( 'enter-notify-event', functions[1] )
        if functions[2] != None: widget.connect( 'leave-notify-event', functions[2] )

def create_IP_List( box ):
    """Create ListView for files in Log"""

    # create tree model of renderMenu ( left panel )
    _renderer = renderer()
    liststore = gtk.ListStore( str )
    mainList = _renderer.renderTreeView( box, liststore, selection_type=gtk.SELECTION_SINGLE )
    _renderer.renderTreeViewColumnText( mainList, _("IP"), 0, sort=True, markup=False )

    return liststore, mainList

def create_File_List( box ):
    """Create ListView for files in Log"""

    # create tree model of renderMenu ( left panel )
    _renderer = renderer()
    liststore = gtk.ListStore( str, gtk.gdk.Pixbuf, str, str )
    mainList = _renderer.renderTreeView( box, liststore, selection_type=gtk.SELECTION_SINGLE, grid_lines=gtk.TREE_VIEW_GRID_LINES_HORIZONTAL )
    _renderer.renderTreeViewColumnText( mainList, _("Time"), 0, sort=True, markup=False )
    _renderer.renderTreeViewColumnPixbuf( mainList, _("I/O"), 1 )
    _renderer.renderTreeViewColumnText( mainList, _("User"), 2, markup=False )
    _renderer.renderTreeViewColumnText( mainList, _("File"), 3, sort=True, markup=False )

    return liststore, mainList
